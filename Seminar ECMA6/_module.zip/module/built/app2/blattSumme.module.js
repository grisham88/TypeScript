export function blattSumme(blatt) {
    return blatt.reduce(function (a, b) {
        return a + b;
    }, 0);
}
