export class Person {
    constructor(name) {
        this.name = name;
    }
    hallo() {
        console.log(`Hallo, ich bin  ${this.name} !`);
    }
}
