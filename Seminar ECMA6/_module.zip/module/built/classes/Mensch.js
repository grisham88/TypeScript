export class Mensch {
    constructor() {
    }
}
