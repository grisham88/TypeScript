export function myParamDecorator(a, b, c) {
    console.log("Param-Decorator aufgerufen", arguments.length, "Argumente.");
    console.log("1. Arg:", a); // Prototype für Method-Param, constructor für constructor
    console.log("2. Arg:", b); // MethodName (undefined für constructor!)
    console.log("3. Arg:", c); // Index d. Params  
    // möglich, aber unsinnig
    a.test3 = "Test 3";
    //return; // ignoriert!
}
