// Modul 1
let test = "Das ist ein Testexport";
let myBlumenArray = ['Rosen', 'Tulpen', 'Nelken'];
export { test, myBlumenArray };
export let myObject = {
    x: "X",
    y: "Y"
};
export function testFunction() {
    console.log("Test!!!");
}
export class Mensch {
    constructor() {
    }
}
