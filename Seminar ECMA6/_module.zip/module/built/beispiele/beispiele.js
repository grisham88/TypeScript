//console.log("In diese Datei werden die Beispiele geladen!");
//console.log("test: ", test); 
