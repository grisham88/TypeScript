//console.log("In diese Datei werden die Beispiele geladen!");
import { test, myBlumenArray } from './modul1';
console.log("test: ", test);
console.log("Blumen", myBlumenArray);
