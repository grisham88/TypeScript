import { lager } from './lager.module';
export class Warenkorb {
    constructor() {
        this.korb = [];
    }
    bestellen(anzahl) {
        console.log(anzahl, "T-Shirts bestellt.");
        lager.ausbuchen(anzahl);
        this.korb.push(anzahl);
    }
    korbauslesen() {
        // gibt die Summe aller Bestellungen zurück
        return this.korb.reduce(function (a, b) {
            return a + b;
        }, 0);
    }
}
