import { Warenkorb } from './warenkorb.module';
let myWarenkorb = new Warenkorb();

export class shop {
    template = `
        <h1>Mein ECMA6 Modul Shop!</h1>
        <p>Geben Sie die Zahl der gewünschten T-Shirts ein!</p>
    `;
    preis = 25;
    input: HTMLInputElement = document.createElement('input');
    korbausgabe: HTMLDivElement = document.createElement('div');
    bestellbutton: HTMLButtonElement = document.createElement('button');
    kaufliste: HTMLElement = document.createElement('ul');

    constructor(){
        let myAppRoot = document.createElement('div');
        myAppRoot.className = 'container';
        // Template zuweisen:
        myAppRoot.innerHTML = this.template;

        this.bestellbutton.innerHTML = "Bestellen!";
        this.bestellbutton.addEventListener('click', this.kaufen.bind(this));

        myAppRoot.appendChild(this.input);
        myAppRoot.appendChild(this.bestellbutton);
        myAppRoot.appendChild(this.kaufliste);
        myAppRoot.appendChild(this.korbausgabe);
        
        document.body.appendChild(myAppRoot);
    }

    getPreis(){
        return this.preis;
    }

    kaufen() {
        console.log(`Ein Test! Kaufe ${this.input.value} Shirts...`);
        let li = document.createElement('li');
        li.innerHTML = `Gekauft: ${this.input.value} Shirts...`;
        this.kaufliste.appendChild(li);
        myWarenkorb.bestellen(Number(this.input.value));
        this.input.value = '';
        this.korbAusgeben();
    }

    korbAusgeben() {
        this.korbausgabe.innerHTML = `
            <b>Gekauft: </b>
            ${myWarenkorb.korbauslesen()} Shirts à ${this.getPreis()} Euro,
            macht ${myWarenkorb.korbauslesen() * this.getPreis()} Euro. Jetzt zahlen?
        `
        
    }
    test() {
        console.log('Ein Test!');
    }

}