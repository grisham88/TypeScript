export class Person {
    name:string;

    constructor(name) {
        this.name = name;
    }
    hallo() {
        console.log(`Hallo, ich bin  ${this.name} !`)
    }
}