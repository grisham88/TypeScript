import { Fahrer } from './Fahrer';
//import { Person } from './Person';


// Importe verwenden...

let myFahrer = new Fahrer("Peter", "Klasse 1", { marke:'BMW', ps:250 });

console.log(myFahrer);
myFahrer.hallo();

// let gustav = new Person('Gustav');
// gustav.hallo();