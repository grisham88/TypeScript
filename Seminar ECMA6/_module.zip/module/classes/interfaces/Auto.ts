export interface Auto {
    marke?:string,
    ps?:number
}