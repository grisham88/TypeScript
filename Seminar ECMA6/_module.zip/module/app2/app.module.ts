// import {hallo} from './hallo.module';
import {karteGeben, blattUpdateDealer} from './dealer';
import {karteVerlangen, blattUpdatePlayer} from './player';

let template = `
    <h1>Black Jack App</h1>
    <p>Machen Sie hier ihr Glück:</p>
`;



let appRoot = document.createElement('div');
    appRoot.innerHTML = template;

let spielerBlatt = document.createElement('input');
    appRoot.appendChild(spielerBlatt);
let karteSpieler = document.createElement('button');
    karteSpieler.innerHTML = "Spieler: Karte";
    karteSpieler.addEventListener('click', function(){
        karteGeben("player");
        spielerBlatt.value = blattUpdatePlayer();
        dealerBlatt.value = blattUpdateDealer();       
    })

    appRoot.appendChild(karteSpieler);

let dealerBlatt = document.createElement('input');
    appRoot.appendChild(dealerBlatt);
let karteDealer = document.createElement('button');
    karteDealer.innerHTML = "Dealer: Karte";
    karteDealer.addEventListener('click', function(){
        karteGeben("dealer");
        spielerBlatt.value = blattUpdatePlayer();
        dealerBlatt.value = blattUpdateDealer();
    })

    appRoot.appendChild(karteDealer);





export class AppModule {
    constructor() {
        document.body.appendChild(appRoot);
    }
}