import {MyClass} from './myClass';

let myClassInstance = new MyClass('Gustav');

console.log(myClassInstance);

myClassInstance.hallo('Yeah!');

myClassInstance.title = "Professor"; // geht nur wg. Acc-Decorator!!

myClassInstance.hallo('Yippee!');
