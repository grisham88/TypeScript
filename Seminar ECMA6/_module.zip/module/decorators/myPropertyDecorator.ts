export function myPropertyDecorator(a, b) :any  {
    console.log("Property-Decorator aufgerufen", arguments.length, "Argumente.");
    console.log("1. Arg:",  a); // Prototype-Object!? Yep.
    console.log("2. Arg:",  b); // propName
    // console.log("this", this); // undefined!

    return {value: 43, writable:true, enumerable:true}
}