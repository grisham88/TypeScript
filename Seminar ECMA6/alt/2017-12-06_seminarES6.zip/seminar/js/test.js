function test2(a=0, b=0) {
    return a + b;
}

var erg = test2();