
function PropertyDecorator(target:any, key:string) {
    console.log("Property wird dekoriert");
    console.log("1. Argument:", target); // die Klasse
    console.log("2. Argument:", key); // Key

    // Closure:
    let testSpeicher;

    return {
        get: function() {
            console.log("Get!")
            return testSpeicher;
        },
        set: function(val) {
            console.log("Set!", val)
            // wohin mit dem Value??
            testSpeicher = val;
        }
    }
}

function PropertyDecorator2(target:any, key:string) {
    // wie kann ich NOCH ein Property erzeugen:
    Object.defineProperty(target.constructor.prototype, key, {
        value:'Dekorierter Toast'
    });
}

class Testklasse { 
    
    @PropertyDecorator test:string;
    @PropertyDecorator2 toast:string;
    
        constructor(test:string) {
     //      this.test = test; // Problem: ALLE INSTANZEN teilen dieses Prop!
        }
        testen() {
            console.log("Ich teste...");
        }
}

let testKlasse = new Testklasse('Bin gespannt...');
console.log("testKlasse: ",testKlasse);
console.log(testKlasse.test);
