function ClassDecoratorFactory(arg:any) {
    console.log("arg", arg); // arg ist ein Objekt

    return function ClassDecorator(target:any) {
        return class extends target {
            // keine ZUSÄTZLICHEN Argumente hier!
            constructor(){
                super(...arguments);
                this.toast = arg.toast || "Ein trockener Toast...";
            }
    
            hallo() {
                console.log("Diesmal mit Class-Prototype-Syntax...");
            }
        }
    }
}



@ClassDecoratorFactory({
    toast:"Toast mit Butter",
    haustier: "Dackel"
})
class Testklasse { 
    
        test:string;
    
        constructor(test:string){
            this.test = test;
        }
        testen() {
            console.log("Ich teste...");
        }
}

let test = new Testklasse('Bin gespannt...');
console.log("test: ",test);