
function MethodDecorator(target:any ,key:string , descr:any) {
    console.log("Method Decorator");
    console.log("Class: ",target);
    // console.log("Prototype: ", target.constructor.prototype)
    console.log("Key: ", key);  
    console.log("Descriptor:", descr);  
    
    // wir haben also eine Methode...
    // draufschalten -> 
    //         ich will das Argument VOR der Funktion
    //         reiche es weiter und starte die Funktion
    //         nehme den Rückgabewert entgegen
    //         gebe ihn zurück

    let oldMethod = descr.value;
    let newMethod = function(...args) {
        // vorher
        let theReturn = oldMethod.apply(this, args);
        // nachher
        console.log("Geplanter Return: ",  theReturn);
        return "Ätsch! " + theReturn;
    }

    // ich gebe einen Descriptor zurück!
    return {
        value: newMethod,
        writable: false,
        enumerable : true,
        configurable: false
    }
}


class Testklasse { 
    
    test:string;
    messgeraet = "Messgerät";
   
        constructor(test:string) {
               this.test = test;
        }

       @MethodDecorator
        testen(derTest:string) {
            console.log("Ich teste mit ",this.messgeraet,":", derTest);
            return "Getestet: " + derTest;
        }
}

let testKlasse = new Testklasse('Bin gespannt...');
console.log("testKlasse: ",testKlasse);
let toasterTest = testKlasse.testen("Toaster");
console.log(toasterTest);
