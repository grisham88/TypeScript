"use strict";
// Der Class Decorator
// declare type ClassDecorator = <TFunction extends Function>(target:TFunction) => TFunction | void;
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
function ClassDecorator(target) {
    console.log("Na dann dekorier ich mal... das Target:", target);
    // ... ich habe jetzt den Constructor in der Hand:
    target.prototype.hallo = function () {
        console.log("Hallo, ich wurde per Decorator hinzugefügt!");
    };
}
function ClassDecorator2(target) {
    console.log("Ich bin der zweite Decorator...", target);
    return class extends target {
        // keine ZUSÄTZLICHEN Argumente hier!
        constructor() {
            super(...arguments);
            this.toast = "Ein trockener Toast...";
        }
        hallo() {
            console.log("Diesmal mit Class-Prototype-Syntax...");
        }
    };
}
function ClassDecorator3(target) {
    console.log("Ich bin der dritte Decorator...", target);
}
function ClassDecorator4(target) {
    console.log("Ich bin der vierte Decorator...", target);
}
let Testklasse = class Testklasse {
    constructor(test) {
        this.test = test;
    }
    testen() {
        console.log("Ich teste...");
    }
};
Testklasse = __decorate([
    ClassDecorator4,
    ClassDecorator3,
    ClassDecorator2,
    __metadata("design:paramtypes", [String])
], Testklasse);
let newTest = new Testklasse('Ein Test');
console.log(newTest);
class SubTestKlasse extends Testklasse {
    supertest() {
        console.log("Super Test!");
    }
}
let subtest = new SubTestKlasse('Ein Supertest');
console.log(subtest);
//# sourceMappingURL=class_decorator.js.map