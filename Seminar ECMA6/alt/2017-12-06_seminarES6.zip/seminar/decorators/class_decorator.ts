// Der Class Decorator
// declare type ClassDecorator = <TFunction extends Function>(target:TFunction) => TFunction | void;


function ClassDecorator(target:any) {
    console.log("Na dann dekorier ich mal... das Target:", target);
    // ... ich habe jetzt den Constructor in der Hand:
    target.prototype.hallo = function() {
        console.log("Hallo, ich wurde per Decorator hinzugefügt!");
    }
}

function ClassDecorator2(target:any) {
    console.log("Ich bin der zweite Decorator...", target);
    return class extends target {
        // keine ZUSÄTZLICHEN Argumente hier!
        constructor(){
            super(...arguments);
            this.toast = "Ein trockener Toast...";
        }

        hallo() {
            console.log("Diesmal mit Class-Prototype-Syntax...");
        }
    }
}

function ClassDecorator3(target:any) {
    console.log("Ich bin der dritte Decorator...", target);
}
function ClassDecorator4(target:any) {
    console.log("Ich bin der vierte Decorator...", target);
}

@ClassDecorator4
@ClassDecorator3
@ClassDecorator2
class Testklasse { 

    test:string;

    constructor(test:string){
        this.test = test;
    }
    testen() {
        console.log("Ich teste...");
    }
}


let newTest = new Testklasse('Ein Test');
console.log(newTest);

class SubTestKlasse extends Testklasse {
    supertest() {
        console.log("Super Test!");
    }
}

let subtest = new SubTestKlasse('Ein Supertest');
console.log(subtest);