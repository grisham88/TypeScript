"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
function MethodDecorator(target, key, descr) {
    console.log("Method Decorator");
    console.log("Class: ", target);
    // console.log("Prototype: ", target.constructor.prototype)
    console.log("Key: ", key);
    console.log("Descriptor:", descr);
    // wir haben also eine Methode...
    // draufschalten -> 
    //         ich will das Argument VOR der Funktion
    //         reiche es weiter und starte die Funktion
    //         nehme den Rückgabewert entgegen
    //         gebe ihn zurück
    let oldMethod = descr.value;
    let newMethod = function (...args) {
        // vorher
        let theReturn = oldMethod.apply(this, args);
        // nachher
        console.log("Geplanter Return: ", theReturn);
        return "Ätsch! " + theReturn;
    };
    // ich gebe einen Descriptor zurück!
    return {
        value: newMethod,
        writable: false,
        enumerable: true,
        configurable: false
    };
}
class Testklasse {
    constructor(test) {
        this.messgeraet = "Messgerät";
        this.test = test;
    }
    testen(derTest) {
        console.log("Ich teste mit ", this.messgeraet, ":", derTest);
        return "Getestet: " + derTest;
    }
}
__decorate([
    MethodDecorator,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], Testklasse.prototype, "testen", null);
let testKlasse = new Testklasse('Bin gespannt...');
console.log("testKlasse: ", testKlasse);
let toasterTest = testKlasse.testen("Toaster");
console.log(toasterTest);
//# sourceMappingURL=method_decorator.js.map