"use strict";
// Hauptmodul, konsumiert andere Module
Object.defineProperty(exports, "__esModule", { value: true });
// -> import
const modulA_1 = require("./modulA");
// Umbenennung beim Import:
const modulB_1 = require("./modulB");
// Import eines Defaultexports:
const modulC_1 = require("./modulC");
// Import "von allem" aus Modul D:
const toolsD = require("./modulD");
// aus A:
console.log(modulA_1.testA); // "Ein Test"
modulA_1.myObj.x = "Kein X mehr";
modulA_1.spezial();
// aus B:
modulB_1.spezial();
// aus C
modulC_1.default.tool1();
// aus D:
let myConst3 = toolsD.Const_3;
//# sourceMappingURL=main.js.map