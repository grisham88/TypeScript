// Modul B

export function spezial() {}