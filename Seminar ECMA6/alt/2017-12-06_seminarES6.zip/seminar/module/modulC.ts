// Modul C:

let Const_1 = 42;
let Const_2 = 17;
function tool1() {}
function tool2() {}

// Default-Export (anonym)
export default {
    Const_1,
    Const_2, 
    tool1,
    tool2
};