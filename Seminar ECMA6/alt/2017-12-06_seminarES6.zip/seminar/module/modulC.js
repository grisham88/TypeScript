"use strict";
// Modul C:
Object.defineProperty(exports, "__esModule", { value: true });
let Const_1 = 42;
let Const_2 = 17;
function tool1() { }
function tool2() { }
// Default-Export (anonym)
exports.default = {
    Const_1,
    Const_2,
    tool1,
    tool2
};
//# sourceMappingURL=modulC.js.map