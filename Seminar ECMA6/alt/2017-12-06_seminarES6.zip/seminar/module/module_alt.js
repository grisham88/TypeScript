// Modulpattern:
(function(){
    // geheim
    let lokal = "Geheim"

    // public
    window.tools = {
        lokal: lokal
    }
})();

// modulA.js:
define("modulA", function() {
    // geheim
    let lokal = "Geheim"

     // public
    return {
        lokal: lokal
    }
});
// app.js
require(['modulA'], function(modulA){
    // modulA!
})