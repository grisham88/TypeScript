// Hauptmodul, konsumiert andere Module

// -> import
import { 
    testA, 
    nochEinTest, 
    test2, // war 'undNochEiner'
    spezial as spezialA,
    myObj 
} from './modulA';

// Umbenennung beim Import:
import { spezial as spezialB } from './modulB';

// Import eines Defaultexports:
import tools from './modulC';

// Import "von allem" aus Modul D:
import * as toolsD from './modulD'


// aus A:
console.log(testA); // "Ein Test"
myObj.x = "Kein X mehr";
spezialA();
// aus B:
spezialB();
// aus C
tools.tool1();
// aus D:
let myConst3 = toolsD.Const_3;
