// Modul D

export let Const_3 = 42;
export let Const_4 = 17;
export function tool3() {}
export function tool4() {}