"use strict";
// Ein Modul ist ein Scope
Object.defineProperty(exports, "__esModule", { value: true });
// automatisch "use strict" !!!
// Schnittstelle anbieten: -> export
exports.testA = "Ein Test";
function spezial() { }
exports.spezial = spezial;
exports.myObj = {
    x: "X",
    y: "Y"
};
let nochEinTest = "Noch ein Test";
exports.nochEinTest = nochEinTest;
let undNochEiner = "Ein weiterer...";
exports.test2 = undNochEiner;
//# sourceMappingURL=modulA.js.map