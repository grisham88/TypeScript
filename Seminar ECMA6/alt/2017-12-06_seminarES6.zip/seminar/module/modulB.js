"use strict";
// Modul B
Object.defineProperty(exports, "__esModule", { value: true });
function spezial() { }
exports.spezial = spezial;
//# sourceMappingURL=modulB.js.map