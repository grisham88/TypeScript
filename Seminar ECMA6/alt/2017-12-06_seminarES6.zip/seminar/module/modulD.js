"use strict";
// Modul D
Object.defineProperty(exports, "__esModule", { value: true });
exports.Const_3 = 42;
exports.Const_4 = 17;
function tool3() { }
exports.tool3 = tool3;
function tool4() { }
exports.tool4 = tool4;
//# sourceMappingURL=modulD.js.map