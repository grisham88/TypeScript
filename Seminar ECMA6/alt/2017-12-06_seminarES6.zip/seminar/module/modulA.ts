// Ein Modul ist ein Scope

// automatisch "use strict" !!!

// Schnittstelle anbieten: -> export
export let testA = "Ein Test";
export function spezial() {}
export let myObj = {
    x:"X",
    y:"Y"
}

let nochEinTest = "Noch ein Test";
let undNochEiner = "Ein weiterer...";

// Aliasing beim Export
export { nochEinTest, undNochEiner as test2}