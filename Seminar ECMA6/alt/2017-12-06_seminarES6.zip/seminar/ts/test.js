"use strict";
function test(a = 0, b = 0) {
    return a + b;
}
var erg = test(5, 7);
//# sourceMappingURL=test.js.map