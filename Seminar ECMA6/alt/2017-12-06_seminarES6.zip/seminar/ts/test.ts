function test(a:number = 0, b:number = 0) :number {
    return a + b;
}

var erg:number = test(5,7);