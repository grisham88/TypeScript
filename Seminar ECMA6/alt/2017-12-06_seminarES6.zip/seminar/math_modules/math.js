"use strict";
// Fasst die beiden Submodule zusammen:
Object.defineProperty(exports, "__esModule", { value: true });
const trigonometry = require("./math/trigonometry");
exports.trigonometry = trigonometry;
const logarithm = require("./math/logarithm");
exports.logarithm = logarithm;
//# sourceMappingURL=math.js.map