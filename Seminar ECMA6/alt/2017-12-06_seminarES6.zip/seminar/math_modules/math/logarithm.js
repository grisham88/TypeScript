"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// exportiert 2 Funktionen
var LN2 = Math.LN2;
var LN10 = Math.LN10;
function getLN2() {
    return LN2;
}
exports.getLN2 = getLN2;
function getLN10() {
    return LN10;
}
exports.getLN10 = getLN10;
//# sourceMappingURL=logarithm.js.map