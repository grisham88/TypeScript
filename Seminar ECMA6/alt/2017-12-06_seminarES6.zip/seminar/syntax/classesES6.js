// sogenannte "Classes"...
"use strict";

class Person {
    // vorgegeben
    constructor(vorname){
        console.log("Ich mache eine Person!");
        this.vorname = vorname;
        // Schlecht (sichtbar)
        // this._lieblingsessen = "Pizza";
        // Besser:
        Object.defineProperty(this, '_lieblingsessen',{
            value:"Pizza",
            writable:true
        })
    }
    // conscise Methods landen im Prototype
    hallo() {
        console.log("Hallo! Ich bin ", this.vorname, " und esse ", this.lieblingsessen);
    }
    // Accessor Property
    get lieblingsessen() {
        return this._lieblingsessen;
    }
    set lieblingsessen(newEssen) {
        // wohin damit??
        this._lieblingsessen = newEssen;
    }
}


console.log(typeof Person);

// cool: ohne 'new' geht nicht!
let peter = new Person("Peter");
console.log("peter: ", peter);
peter.hallo();
console.log(peter.lieblingsessen);
peter.lieblingsessen = "Pasta";
console.log(peter.lieblingsessen);

// vererben:

class Fahrer extends Person {
    constructor(vorname, auto){
        // Konstruktor der Super-Klasse aufrufen:
        super(vorname);
        this.auto = auto;
    }
    fahren() {
        console.log("Ich fahre ", this.auto);
    }
}

let hans = new Fahrer("Hans","BMW");
console.log(hans);
hans.fahren();