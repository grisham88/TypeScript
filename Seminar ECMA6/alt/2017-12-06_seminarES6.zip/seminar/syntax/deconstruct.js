"use strict";
// Deconstruction
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
let myNumArray3 = [17, 12, 11, 9, 7];
let [item1, item2] = myNumArray3;
console.log("item1: ", item1);
console.log("item2: ", item2);
let [itemA, , itemC] = myNumArray3;
let [itemX, itemY, ...arrayRest] = myNumArray3;
console.log("arrayRest: ", arrayRest);
let myObjXYZ = {
    x: "X",
    y: "Y",
    z: "Z",
    o: "0",
    p: "P"
};
let { x, z } = myObjXYZ;
console.log("z: ", z);
// Propvariablen können "gealiast werden: propName:varName
let { x: myX, z: myZ } = myObjXYZ, objRest = __rest(myObjXYZ, ["x", "z"]);
console.log("myZ: ", myZ);
console.log("objRest: ", objRest);
function testDeconstr() {
    console.log(arguments);
    let [theObj, ...args] = arguments;
    console.log(theObj);
}
testDeconstr(myObjXYZ, 42, 43, 44);
let objX = { x: "x", y: "Y von X" };
let objY = { y: "Y von Y", z: "Z" };
let objXY = Object.assign({}, objX, objY);
console.log("objXY:", objXY);
let objZ = Object.assign({ z: "Z" }, objX);
//# sourceMappingURL=deconstruct.js.map