
let y = "Y";
let z = "Z";
let p = "P";
let q = "Q";
let f = function(){}

let bKey = 'b';
let cKey = 'c';

let myObjectLiteral:any = {
    // normale Props
    "x": "X",
    // normale Methode
    hallo : function() {
        console.log("Hey!")
    },
    // computed Property
    [cKey]: "C",
    // concise Properties!
    z,
    // concise Method:
    hi() {
        console.log("Hi!");
    }
};
myObjectLiteral['a'] = "A";
myObjectLiteral[bKey] = "B"

console.log(myObjectLiteral);

let mySymbolKey = Symbol('mySymbolKey');
console.log("mySymbolKey", mySymbolKey);

let myOtherSymbol = Symbol('Hohoho');
console.log("myOtherSymbol", myOtherSymbol);
let myOtherSymbol2 = Symbol('Hohoho');
console.log("myOtherSymbol2", myOtherSymbol2);
console.log(myOtherSymbol2 === myOtherSymbol); // nein! Sind NIE gleich!

let nochEinObjekt:any = {
    a:"A",
    b:"B",
    [mySymbolKey]: "Cool, oder?"
};

for(let key in nochEinObjekt) {
    console.log(key, ":", nochEinObjekt[key] );
}

/* Object() bietet Methoden:

    Object.defineProperty(o)
    Object.preventExtensions(o);
    Object.seal(o);
    Object.freeze(o);
    Object.keys(o); // -> Liste der Keys
    Object.getOwnPropertyNames(o)
    Object.getOwnPropertySymbols(o)
*/


// Keys lesen:
let dieKeys = Object.keys(nochEinObjekt);
console.log(dieKeys);
let dieProps = Object.getOwnPropertyNames(nochEinObjekt);
console.log(dieProps);
let dieSymbols = Object.getOwnPropertySymbols(nochEinObjekt);
console.log(dieSymbols);
let [firstSymbol] = dieSymbols;
firstSymbol = firstSymbol.toString().substring(7);
console.log("firstSymbol:", firstSymbol);

console.log(nochEinObjekt[mySymbolKey]);


