"use strict";
// Bei Arrays gibt es Neues:
// statische Methoden
let arr = [1, 2, 3];
console.log(typeof arr); // -> object
console.log(arr instanceof Array); // -> true
console.log(Array.isArray(arr));
// Array.of() // -> konstruiert ein Array
let myConstArray = new Array(1, 2, 3);
console.log(myConstArray);
let nochEinArray = Array.of(1, 2, 3);
console.log(nochEinArray);
let myOoopsArray = new Array(5);
console.log(myOoopsArray);
let keinOopsArray = Array.of(5);
console.log(keinOopsArray);
// Array.from() -> baut ein Array aus ... EGAL
// MUSS: length-Prop, num. Key(s)
let keinArray = {
    egal: "Fällt raus",
    4: "Verboten",
    '5': "Die Fünf",
    length: 7
};
let jetztEinArray = Array.from(keinArray);
console.log(jetztEinArray);
// for...of
for (let val of arr) {
    console.log(val);
}
console.log(..."Echt jetzt?");
for (let char of "Echt jetzt?") {
    //  console.log(char);
}
let blumen = ["Rosen", "Tulpen", "Nelken"];
// wir machen einen Iterator:
let meinIterator = blumen.entries();
console.log(meinIterator);
// Aufruf von next() auf Iterator -> value-Object
let firstNext = meinIterator.next();
console.log(firstNext);
let secondNext = meinIterator.next();
console.log(secondNext);
let thirdNext = meinIterator.next();
console.log(thirdNext);
let fourthNext = meinIterator.next();
console.log(fourthNext);
console.log(...blumen.entries());
//# sourceMappingURL=arraysyntax.js.map