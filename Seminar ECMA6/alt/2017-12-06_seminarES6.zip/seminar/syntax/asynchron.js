"use strict";
// Asynchron mit fetch()
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
console.log(fetch);
fetch('../data/personen.json', {
    method: 'get'
})
    .then(function success(response) {
    console.log(response);
    if (response.status < 400) {
        return response.json();
    }
    else {
        throw new Error('Fehler');
    }
})
    .then(function (data) {
    console.log(data);
});
// Ajax mit Generator
// 3 Dinge:
// a) Ajaxer... formuliert einen Request: url, cb
//      - liefert Daten
// b) Generatorfunktion ...definiert den Ablauf der Aktion
//      - verwendet den Runner, übergibt URL
//      - nimmt Daten vom Runner entgegen
// c) Runner... vermittelt zwischen Generator und dem Ajaxer
//      - startet die Requests, gibt an Ajaxer URL und CB
//      - gibt Daten an den Generator zurück
function ajaxer(url, cb) {
    let xhr = new XMLHttpRequest();
    xhr.open('get', url, true);
    xhr.onload = cb;
    xhr.send();
}
function* ajaxGeneratorFunction() {
    // ajaxRunner aufrufen
    let result;
    ajaxRunner('../data/frida.json');
    result = yield;
    console.log("1.: ", result);
    ajaxRunner('../data/josef.json');
    result = yield;
    console.log("2.: ", result);
    ajaxRunner('../data/gerda.json');
    result = yield;
    console.log("3.: ", result);
    ajaxRunner('../data/heiner.json');
    result = yield;
    console.log("4.: ", result);
}
let myAjaxGenerator = ajaxGeneratorFunction();
function ajaxRunner(url) {
    // ruft ajaxer
    ajaxer(url, function () {
        // der XHR-Prozess ist thisObj!
        if (this.status < 400) {
            myAjaxGenerator.next(this.responseText);
        }
        else {
            myAjaxGenerator.throw('Ooops');
        }
    });
}
;
// Generator anwerfen:
myAjaxGenerator.next();
// mit async/await
function holDatenAsynchron(url) {
    return __awaiter(this, void 0, void 0, function* () {
        let daten = yield fetch(url);
        console.log("daten await:", daten);
        return daten;
    });
}
let santa = holDatenAsynchron('../data/santa.json');
santa.then(function (data) {
    return data.json();
}).then(function (data) {
    console.log("santa:", data);
});
//# sourceMappingURL=asynchron.js.map