// aus der Sicht von TypeScript

let myA;
  console.log(typeof myA); // undefined
    myA = "Test";
    myA = 42;
    myA = false;
    myA = { x:"X" }

let myB = "Test";
    myB = 42;

let myC: number; 
   // myC = "Test";
    myC = 42;

    myC = null;      // ok, solange nicht "strictNullChecks": true
    myC = undefined; // ok, s.o.

let myD = null;  // implicit any
    console.log(typeof myD); // object

let myE:number = null;    

    // compound types:
let myNumBool: (number | boolean) = 42;
    myNumBool = true;
    myNumBool = "Peng";

let myObj = { x: "X", y:"Y" };

    myObj = {x:"Ein X", y:"Ein y"}

let myOtherObj: { z:string, q:string };

myOtherObj.z = "Ein Z";
myOtherObj = { z:"Z", q:"P"}
