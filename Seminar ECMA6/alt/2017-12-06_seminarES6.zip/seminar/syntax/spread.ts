let stringArray: string[];
let stringBoolArray: (string | boolean)[];
let objxArray: {x:string}[];
let anythingGoesArray: any[];

// let userArray: User[];


let addiere = function(a, b, c) {
    return a + b + c;
}

let erg2 = addiere(5,7,9);
console.log("erg2:", erg2);

let numArray = [7,12,5];

// ein Array in Einzelwerte zerlegen: ...
erg2 = addiere(...numArray); // Spread!
console.log("erg2:", erg2);

let numArray2 = [17,12];

// let numArray3 = numArray2.concat(numArray);
let numArray3 = [98, ...numArray2, 99, ...numArray]
console.log(numArray3);

// aus Einzelwerten ein Array machen: ...
let machWas = function(...args) { // Rest!
    console.log(arguments);
    // Array.prototype.forEach.call(arguments, function(val){
    //     console.log(val);
    // });
    console.log("args", args);
    args.forEach(function(val){
        console.log(val);
    });
};

machWas(["So","isses"]);