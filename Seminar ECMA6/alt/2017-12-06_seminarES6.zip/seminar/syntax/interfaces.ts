interface Wichtel {
    hoehe:number;
    gewicht:number;
    farbe:string;
}
// Interfaces sind NICHT instanzierbar
// let wichtel = new Wichtel();
// console.log(wichtel);

interface Spitzemuetze {
    spitzemuetze:boolean;
}
interface Werkzeuge {
    hammer?:boolean;
    spitzhacke?:boolean;
}

class Gnom implements Wichtel, Spitzemuetze {
    // Property anmelden UND initialisieren!!!
    spitzemuetze = true; // INSTANZEIGENSCHAFT!!!
    static kleinwuechsig = true;
    static gnomenzahler = 0;

    constructor(public hoehe:number, public gewicht:number, public farbe:string) {
        Gnom.gnomenzahler++;
     }
    get kleinwuechsig() {
        return Gnom.kleinwuechsig;
    }
    static singen() {
        console.log("La la la...");
    }

}

let alberich = new Gnom(50, 100, 'rot');
console.log(alberich);
console.log(alberich.kleinwuechsig);

class Zwerg extends Gnom  {
    werkzeuge: any;
    constructor(hoehe:number, gewicht:number, farbe:string, werkzeuge: Werkzeuge) {
        super(hoehe, gewicht, farbe);
        this.werkzeuge = werkzeuge;
    }
    werkzeugeAusgeben() {
        return this.werkzeuge;
    }
}

let thorin = new Zwerg(80, 120,'gold', {spitzhacke:true});
let thorinsWerkzeuge = <Werkzeuge>thorin.werkzeugeAusgeben();

