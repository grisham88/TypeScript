"use strict";
class Gnom {
    constructor(hoehe, gewicht, farbe) {
        this.hoehe = hoehe;
        this.gewicht = gewicht;
        this.farbe = farbe;
        // Property anmelden UND initialisieren!!!
        this.spitzemuetze = true; // INSTANZEIGENSCHAFT!!!
        Gnom.gnomenzahler++;
    }
    get kleinwuechsig() {
        return Gnom.kleinwuechsig;
    }
    static singen() {
        console.log("La la la...");
    }
}
Gnom.kleinwuechsig = true;
Gnom.gnomenzahler = 0;
let alberich = new Gnom(50, 100, 'rot');
console.log(alberich);
console.log(alberich.kleinwuechsig);
class Zwerg extends Gnom {
    constructor(hoehe, gewicht, farbe, werkzeuge) {
        super(hoehe, gewicht, farbe);
        this.werkzeuge = werkzeuge;
    }
    werkzeugeAusgeben() {
        return this.werkzeuge;
    }
}
let thorin = new Zwerg(80, 120, 'gold', { spitzhacke: true });
let thorinsWerkzeuge = thorin.werkzeugeAusgeben();
//# sourceMappingURL=interfaces.js.map