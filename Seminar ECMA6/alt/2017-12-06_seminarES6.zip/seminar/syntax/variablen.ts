// Es gibt neue Arten, Variablen zu definieren

// werden gehoistet => kein Blockscope
var a = 5;

function testFn (){
    console.log("Das ist ein Test!");
}



// Blockscopevariablen:

let testFn2 = function() {
    console.log("Das ist auch ein Test!");
}

let b = 7;

let c;

for(let i = 0; i<5; i++) {
    let temp = "egal";
    const konstant = "Ich werde beim Durchlauf nicht mehr geändert...";
}
// console.log(i); // kein oops mehr :-)

const d = "Eine Konstante, d.h., der Wert DARF NICHT geändert werden.";

const statischeFn = function() {
    console.log("Mich kann man nicht überschreiben...");
}

statischeFn();