// Fat Arrow Funktionen oder Lambdas
"use strict";
console.log("draussen:", this);
let myObj99 = {
    x: "X",
    meth: function () {
        console.log("this:", this);
        console.log("Mein x-Prop:", this.x);
        // Kontext speichern
        let that = this;
        let xLesen = function () {
            // thisObj wird übergeben! Ist "undefined" im Strict Mode
            console.log("Function: Na dann... Ich lese ", this.x);
        };
        // Kontext übergeben: 
        xLesen.call(this);
        let xLesenArrow = () => console.log("Arrow: Na dann... Ich lese ", this.x);
        xLesenArrow();
        return xLesenArrow;
    }
};
let myDraussenXlesenArrow = myObj99.meth();
myDraussenXlesenArrow();
// function myFunction () {
//     console.log("this:", this);
//     return "X"
// }
let myFunction = function () {
    // thisObj wird übergeben! Ist "undefined" im Strict Mode
    console.log("Function this:", this);
    return "X";
};
myFunction();
let myArrowFunction = () => "X";
let myArrowFunction2 = x => 2 * x;
let myArrowFunction3 = (x, y) => x + y; // Summe
let myArrowFunction4 = (x, y, z) => [x, y, z]; // Array!
// hier ist ein "this"...
let myArrowFunction5 = () => {
    // es wird KEIN thisObj übergeben! Nie!
    // this wird aus der Umgebung geholt. Lexikalisch.
    // es gibt KEIN arguments-Objekt!!
    console.log("Arrow this:", this);
    return "Arrow X";
};
let myErg99 = myArrowFunction5();
console.log("myErg99:", myErg99);
let myX99 = myArrowFunction();
console.log(myX99);
[1, 2, 3, 4].forEach(val => console.log(val));
//# sourceMappingURL=arrowfunctions.js.map