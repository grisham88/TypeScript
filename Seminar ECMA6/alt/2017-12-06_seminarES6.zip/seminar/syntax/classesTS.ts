// ... und jetzt Classes in TypeScript....

// die Klasse
class Person {
    // für TS: Props "anmelden":
    public vorname:string;

    // der Konstruktor
    constructor(vorname: string, 
                public alter:number, 
                private creditcardNr:number,
                protected haustier:string) {
        this.vorname = vorname;
    }
    hallo() {
        console.log("Hallo! Ich bin", this.vorname, ". Kredit: ", this.creditcardNr);
    }
}


let peter = new Person("Peter", 42, 555555666, "Katze");
console.log("peter: ", peter);
peter.hallo();

console.log(peter.alter);
// console.log(peter.creditcardNr); // VERBOTEN, privat!
console.log(peter.haustier);        // Verboten, protected!

// wir vererben
class Fahrer extends Person {

    constructor(vorname:string, 
                alter:number, 
                creditcardNr:number,
                haustier:string,
                public auto:string ){
        // Konstruktor der Super-Klasse aufrufen:
        super(vorname, alter, creditcardNr,haustier);
    }
    fahren() {
        // hier NICHT Zugriff auf Private der Superklasse
        // ABER: Potected der Superklasse DARF ICH.
        console.log("Ich fahre ", this.auto, "und habe Kredit: ", this.haustier);
    }
}

let hans = new Fahrer("Hans", 33, 666333999,"Dackel", "BMW");
hans.fahren()

