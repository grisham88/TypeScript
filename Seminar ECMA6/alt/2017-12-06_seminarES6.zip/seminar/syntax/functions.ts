// es geht um Funktionen

// Parameter können optional sein (mit ?)
// ... ODER einen Defaultwert erhalten
function myTypedFunction(a?:number , b:number = 0) : number {
   if(!a) {
       a = 42;
   }
   return a + b; 
}

let ergFn = myTypedFunction(6, 7);
console.log(ergFn);
ergFn = myTypedFunction(17);
console.log(ergFn);
ergFn = myTypedFunction();
console.log(ergFn);