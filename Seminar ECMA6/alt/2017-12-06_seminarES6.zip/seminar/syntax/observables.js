"use strict";
// erstmal ein normales Array her....
let blumenArray = ["Rosen", "Tulpen", "Nelken", "Geranien", "Petunien", "Veilchen"];
// Observable bekomme ich von RxJS:
let blumenObs = Rx.Observable.from(blumenArray).subscribe(val => console.log("onNext: ", val), // onNext
() => console.log("onError"), // onError
() => console.log("onCompleted") // am Ende
);
console.log(blumenObs);
let blumenObs2 = Rx.Observable.from(blumenArray);
blumenObs2
    .take(3)
    .startWith("Los geht's...")
    .subscribe(val => console.log("onNext: ", val));
window.onload = function () {
    let btn = document.getElementById('btn');
    let inp = document.getElementById('textinput');
    // Klickstream!
    Rx.Observable.fromEvent(btn, 'click')
        .subscribe(e => console.log("onNext: ", e));
    // Inputstream!
    Rx.Observable.fromEvent(inp, 'input')
        .debounceTime(300)
        .subscribe(e => console.log("onNext: ", inp.value));
};
//# sourceMappingURL=observables.js.map