// ... es geht um Strings!

let myString = "Das ist ein 'irgendwie'" +
                "String...";

let myOtherString = ' Das ist "auch" ein String';

let myHTMLString = "<ul>" +
                    "<li>Test</li>" +
                    "</ul>";

let ultraCoolerString = `Das ist ultracool?`;

let ultraCoolHtml = `
        <ul>
            <li>Test</li>
            <li>Test</li>
            <li>Test</li>
            <li>Test</li>
        </ul>  
`;

let vorname = "Peter";
let nachname = "Panter";

let gruss = `Hallo, mein Name ist ${vorname} ${nachname}! Cool.`;

console.log(gruss);

vorname = "Paulchen";
console.log(gruss);

function titel() {
    return  "Dr";
}

function gruessen(vorname:string, nachname:string, ) :string {
    return `Hallo, mein Name ist ${titel()} ${vorname} ${nachname}! Cool.`;
}

console.log(gruessen("Klaus", "Klever"));
