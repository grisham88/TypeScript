"use strict";
// Generatoren etc.
function* meineGeneratorFunction() {
    console.log("Das ist der erste Streich...");
    yield 1;
    console.log("... und der nächste folgt sogleich.");
    yield 2;
    console.log("Und noch ein Gedicht...");
    yield 3;
    console.log("Und zum Schluss...");
    return 42;
}
// hier ist der Generator!
let meinGenerator = meineGeneratorFunction();
console.log(meinGenerator);
let first = meinGenerator.next();
console.log(first);
let second = meinGenerator.next();
console.log(second);
let third = meinGenerator.next();
console.log(third);
let fourth = meinGenerator.next();
console.log(fourth);
let meinGenerator2 = meineGeneratorFunction();
for (let val of meinGenerator2) {
    console.log(val);
}
let meinGenerator3 = meineGeneratorFunction();
let letzter = meinGenerator3.return();
console.log("letzter:", letzter);
let meinGenerator4 = meineGeneratorFunction();
// let mythrow = meinGenerator4.throw(new Error('Fehler!')); // -> das war's dann!
// console.log("mythrow:", mythrow);
function* ganzeZahlen(start) {
    let n = start;
    while (true) {
        yield n++;
    }
}
let zahlenreihe = ganzeZahlen(1);
let one = zahlenreihe.next();
function addiere(a) {
    return function (b) {
        return a + b;
    };
}
let dieFuenf = addiere(5);
let sieben = dieFuenf(2);
let acht = addiere(4)(4);
function* meineGeneratorFunction2(x) {
    console.log("Jetzt passiert was...");
    //           |
    let in1 = (yield);
    console.log("in1:", in1);
    let zwischenwert = x * in1;
    //           |
    let in2 = (yield);
    let result = zwischenwert * in2;
    // |
    yield result;
}
let genInput = meineGeneratorFunction2(5);
let out1 = genInput.next(); // Erster Schritt! Muss!
console.log(out1.value);
let out2 = genInput.next(4);
console.log(out2.value);
let out3 = genInput.next(2);
console.log(out3.value);
//# sourceMappingURL=generatoren.js.map