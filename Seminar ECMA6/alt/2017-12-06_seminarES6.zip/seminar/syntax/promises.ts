// Ajax ohne

let xhr = new XMLHttpRequest();
    xhr.open('get','../data/personen.json', true);
    xhr.onload = () => {
        if(xhr.status < 400) {
            console.log(xhr.responseText);
        } else {
            console.log("Oops...");
        }
    }
    xhr.onerror = () => {
        console.log("Erst recht oops...");
    }
    xhr.send();

// ... erstmal ein Promise:
new Promise(handlerFunction);
let myPromise = new Promise(function(resolve, reject){
    console.log("Aha...", arguments);

    setTimeout(function() {
        resolve(42); // "erfüllt" das Promise
    }, 2000);
     
    reject('Wir haben einen Oops...'); // weist Promise zurück
});

console.log(myPromise);
myPromise.then(function(input){
    console.log("Hier bin ich! ", input);
}, function(err) {
    console.log("Jetzt bin ich hier...", err);
});

setTimeout(function() {
    myPromise.then(function(input){
        console.log("Später: Hier bin ich!", input);
    }, function(err) {
        console.log("Später: Jetzt bin ich hier...", err);
    });
}, 5000);

// ... Ajax mit Promise
let myAjaxPromise = new Promise(function(resolve, reject){
        // HIER: asynchronen Vorgang starten
        let xhr = new XMLHttpRequest();
        xhr.open('get','../data/personenFail.json', true);
        xhr.onload = () => {
            if(xhr.status < 400) {
                resolve(xhr.responseText);
            } else {
                reject("Oops...");
            }
        }
        xhr.onerror = () => {
            reject("Erst recht oops...");
        }
        xhr.send();
});

let myAjaxPromiseLevel2 = myAjaxPromise.then(function(daten) {
    console.log("Stufe 1: Promise liefert... ", daten);
    if(JSON.parse(daten).success) {
        return JSON.parse(daten).personen;
    } else {
        throw new Error('Keine Daten auf Stufe 1');
    }
    
}, function(err) {
    console.log("Stufe 1: Fehler", err);
    // return 17; // triggert AUCH Success
    throw new Error('Fehler auf Stufe 1');
});

console.log("myAjaxPromiseLevel2:", myAjaxPromiseLevel2);

myAjaxPromiseLevel2.then(function(daten){
    console.log("Stufe 2: Cool. Oder?", daten);
    // eigentliche Verarbeitung...
}, function(err) {
    console.log("Stufe 2: Fehler", err);
});


