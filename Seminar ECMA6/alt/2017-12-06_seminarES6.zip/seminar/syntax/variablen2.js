"use strict";
// aus der Sicht von TypeScript
let myA;
console.log(typeof myA); // undefined
myA = "Test";
myA = 42;
myA = false;
myA = { x: "X" };
let myB = "Test";
myB = 42;
let myC;
// myC = "Test";
myC = 42;
myC = null; // ok, solange nicht "strictNullChecks": true
myC = undefined; // ok, s.o.
let myD = null; // implicit any
console.log(typeof myD); // object
let myE = null;
// compound types:
let myNumBool = 42;
myNumBool = true;
myNumBool = "Peng";
let myObj = { x: "X", y: "Y" };
myObj = { x: "Ein X", y: "Ein y" };
let myOtherObj;
myOtherObj.z = "Ein Z";
myOtherObj = { z: "Z", q: "P" };
//# sourceMappingURL=variablen2.js.map