// Asynchron mit fetch()

console.log(fetch);

fetch('../data/personen.json', {
    method:'get'
})
// Stufe 1
.then(function success(response){
    console.log(response);
    if(response.status < 400) {
        return response.json();
    } else {
        throw new Error('Fehler');
    }
})
// Stufe 2
.then(function(data) {
    console.log(data);
});

// Ajax mit Generator
    // 3 Dinge:
    // a) Ajaxer... formuliert einen Request: url, cb
    //      - liefert Daten
    // b) Generatorfunktion ...definiert den Ablauf der Aktion
    //      - verwendet den Runner, übergibt URL
    //      - nimmt Daten vom Runner entgegen
    // c) Runner... vermittelt zwischen Generator und dem Ajaxer
    //      - startet die Requests, gibt an Ajaxer URL und CB
    //      - gibt Daten an den Generator zurück

    function ajaxer(url:string, cb:()=>void) {
        let xhr = new XMLHttpRequest();
        xhr.open('get', url, true);
        xhr.onload = cb;
        xhr.send();
    }

    function * ajaxGeneratorFunction() {
        // ajaxRunner aufrufen
        let result;
        ajaxRunner('../data/frida.json');
        result = yield;
        console.log("1.: ", result);
        ajaxRunner('../data/josef.json');
        result = yield;
        console.log("2.: ", result);
        ajaxRunner('../data/gerda.json');
        result = yield;
        console.log("3.: ", result);
        ajaxRunner('../data/heiner.json');
        result = yield;
        console.log("4.: ", result);
    }

    let myAjaxGenerator = ajaxGeneratorFunction();

    function ajaxRunner(url) {
        // ruft ajaxer
        ajaxer(url, function(){
            // der XHR-Prozess ist thisObj!
            if(this.status < 400) {
                myAjaxGenerator.next(this.responseText);
            } else {
                myAjaxGenerator.throw('Ooops');
            }
        });
    };

    // Generator anwerfen:
    myAjaxGenerator.next();


    // mit async/await
    async function holDatenAsynchron(url) {
        let daten =  await fetch(url);
        console.log("daten await:", daten);
        return daten;
    }

    let santa = holDatenAsynchron('../data/santa.json');
    santa.then(function(data){
        return data.json()
    }).then(function(data) {
        console.log("santa:", data);
    })
  
