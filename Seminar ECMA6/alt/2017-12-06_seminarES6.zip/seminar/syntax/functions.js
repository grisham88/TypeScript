"use strict";
// es geht um Funktionen
// Parameter können optional sein (mit ?)
// ... ODER einen Defaultwert erhalten
function myTypedFunction(a, b = 0) {
    if (!a) {
        a = 42;
    }
    return a + b;
}
let ergFn = myTypedFunction(6, 7);
console.log(ergFn);
ergFn = myTypedFunction(17);
console.log(ergFn);
ergFn = myTypedFunction();
console.log(ergFn);
//# sourceMappingURL=functions.js.map