import {a, objX, blumen, speicherA, liesSpeicherA} from './modulA';



console.log("ModulB-a: ", a);

let dasX = objX.x;
console.log("ModulB-objx: ", dasX);

let speicher = {
    write: speicherA,
    read: liesSpeicherA
}

export { speicher }

