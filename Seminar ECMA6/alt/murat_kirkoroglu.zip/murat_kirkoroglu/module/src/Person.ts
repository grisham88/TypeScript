

class Person{

    constructor(public vorname:string){
        hallo(){
            console.log("Hallo Person Modul");            
        }
    }

}


export Person;