import {namedExpor} from './modulD';
// Pauschaler Import
import * as boxA from  './modulA';

console.log(boxA);
