
export let namedExport = "Ich bin ein Export";

export default{
    const_1: 17,
    const_2: 4,
    tool_1: function(){},
    tool_2:function(){},
}