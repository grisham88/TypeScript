import { speicher  as derSpeicher } from './modulB';


let speicher = {
    super: "Toll"
}

console.log(derSpeicher);

derSpeicher.write(87);
derSpeicher.write(187);
derSpeicher.write(897);
derSpeicher.write(847);
console.log(derSpeicher.read())
