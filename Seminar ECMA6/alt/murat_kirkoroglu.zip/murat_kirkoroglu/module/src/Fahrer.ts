import { Person } from './Person';


class Fahrer extends Person{

    constructor(...arg){
        super(...arg);
    }

    fahren(){
        console.log("Modul Fahrer");
    }
}


export Fahrer;