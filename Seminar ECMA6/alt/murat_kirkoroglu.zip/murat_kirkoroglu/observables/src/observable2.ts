// wir brauchen einen DOM-Knoten

//let btn: HTMLButtonElement | null = <HTMLButtonElement | null>document.getElementById('btn');
let btn: HTMLButtonElement | null = document.getElementById('btn') as HTMLButtonElement;

let btnObservable = Rx.Observable.fromEvent(btn, 'click');

btnObservable
.filter(evt => evt.clientX > 100)
.map(evt => `Klick an Position ${evt.clientX} px!`)
.subscribe(pos => console.log("pos", pos));

//Inputstream
let myInput: HTMLInputElement = document.getElementById('myText') as HTMLInputElement;

let inputObservable = Rx.Observable.fromEvent(myInput, 'input');
inputObservable.subscribe(evt => console.log("evt", evt.target) );