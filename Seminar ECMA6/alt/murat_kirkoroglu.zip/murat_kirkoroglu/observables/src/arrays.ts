// Arrays
// sind Iterables
// haben entries()
// sind mit for-of zu verarbeiten
// haben "higher order"- Methods

let testdaten = [12,4,5,6,47,8,1,5,7,85,1,55,98];
console.log("testdaten:", testdaten);
// haben "higher order"- Methods: higherOrderMethod(fn) die arbeitet mit einer Funtion 
// also das wären:forEach(), .some(), .every(), filter(), .reduce(), .reduceRight() 

console.log('\n');
let gefiltert = testdaten.filter(item => item > 10);
console.log("gefiltert:", gefiltert);
console.log('\n');
let gemappt = gefiltert.map(item => item * item);
console.log("gemappt:", gemappt);
console.log('\n');
let reduziert = gemappt.reduce( (a, b) => a + b);
console.log("reduziert:", reduziert);

