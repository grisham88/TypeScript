let arr = [1,2,3,4];
let iterator = arr.entries();

//ValueObjekt
let iteratorValue = iterator.next();
console.log("iteratorValue:", iteratorValue);

// entspricht den Iterable
function anweisungen(){
    console.log("Tu dies");
    console.log("Tu dad");
    console.log("Tu jenes");
    console.log("Tu noch was");
    return 42;
}

// entspricht den Genearor
function * anweisungenStar(): IterableIterator<number>{
    console.log("Tu dies");
    yield 15; // hier mal anhalten
    console.log("Tu dad");
    yield; // hier mal anhalten
    console.log("Tu jenes");
    yield; // hier mal anhalten
    console.log("Tu noch was");
    return 42;
}

let myGenerator = anweisungenStar();
let genValue = myGenerator.next();

console.log("genValue.value:", genValue.value);


