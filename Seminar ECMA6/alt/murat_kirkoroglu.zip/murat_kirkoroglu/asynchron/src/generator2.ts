// ich brauch Zahlen...
let sequenz = [2,3,4,5,6,17,75];

//generator *(Wichtig ist der Stern)
function * zahlenreihe(){
    let n = 2;

    while(true){
        yield n;
        n = n * 2;
        //Abbruchbedingung
        if (n > 10000000){
            return;    
        }
    }
}

let dieZahlen = zahlenreihe();

let zahl1 = dieZahlen.next(); //Start
console.log(zahl1);
let zahl2 = dieZahlen.next(); //Start
console.log(zahl2);
let zahl3 = dieZahlen.next(); //Start
console.log(zahl3);

let mehZahlen = zahlenreihe();

for(let zahl of mehZahlen){
    console.log("for-zahl:", zahl);
}