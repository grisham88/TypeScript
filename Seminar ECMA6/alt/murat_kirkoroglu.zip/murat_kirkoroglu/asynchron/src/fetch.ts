// Die fetch-API

fetch('../data/personen.json').then(function(response){
    console.log(response)
    if(response.status!==200) {
        return; // raus hier!
    }
    response.json().then(function(data){
        console.log("data:", data);
    });
});
// oder so:
fetch('../data/personen.json')
.then(function(response){
    if(response.status===200) {
        return response; // 
    }
})
.then( response => response.json())
.then(data => console.log(data));

