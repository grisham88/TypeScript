// 3 Dinge brauchen wir
// a) Sequenz, also die Generatorfunction
// b) eine Funktion(Ajaxer), die den Request durchführt
// c) eine Funktion(Ajaxrunner), die zwischen Ajaxer und Generator

function * ajaxSequenz(){
    // mehrere Calls sollen abgesetzt werden


}

let mySequenz = ajaxSequenz();

function ajaxer(url: string, callback){
    // führt Call durch
    // bildet XMLHttpRequest
    // hier brauch in den Callback

let call = new XMLHttpRequest();
    call.open('get', url, true);
    call.onload = function(){
        if(this.status < 400){
            mySequenz.next(this.responseText);
        }
    }
    call.send();    
}

function ajaxRunner(url: String){
    // bildet den Callback
    // beauftragt den Call mitURL und CallBack    
    ajaxer(url, function(){
        if(this.status < 400){
            mySequenz.next(this.responseText);
        }

    });

    // benachrichtigt Generator mySequenz

}
