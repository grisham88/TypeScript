// Promise/A

let promLevel1 = new Promise(function(resolve, reject){
    console.log("Läuft...", arguments);
    // Promise ist "pending" (1. Zustand)

    // HIER starte ich den asynchronen Vorgang:
        let req = new XMLHttpRequest();
        req.open('get','../data/personen.json',true);
        req.onload = function(){
            if(this.readyState===4 && this.status === 200) {
               // hier Promise resolven:
               resolve(this.responseText);
            }
            if(this.readyState===4 && this.status !== 200) {
                reject('Ging schief'); 
            }
        }
        req.onerror = function(){
            reject('Ging schief'); 
        }
        req.send();  // Daten angefordert
});

// Callback ans Promise binden:
let promLevel2 = promLevel1.then(
    // Success:
    function(response){
        console.log("response: ", response);
        let respObj = JSON.parse(response);
        if(respObj.success) {
            return respObj.personen; // geht nach Level 2!!
        } else {
            throw new Error("Daten unbrauchbar!");
        }   
    },
    // ERROR:
    function(err){
        console.log("Wir haben einen Ooops...", err);
        throw new Error(err);
    }
);
promLevel2.then(function(data){
    console.log("Hier ist Level2 Success!", data)
}, function(err){
    console.log("Jetzt gibt's Ärger...", err);
})

promLevel1.then(function(response){
    console.log("Callback 2: ",response);
    return 17;
}, function(){
    console.log("Ooops");
}).then(function(data){
    console.log("Hier ist der andere Level2 Success!", data)
}, function(err){
    console.log("Jetzt gibt's Ärger...");
});

