
function * buslinie(val){
    console.log("Vor dem Yield");
    val = yield;
    console.log("Nach dem Yield", val);
    val = yield;
    console.log("Nach dem Yield", val);
    return val + val;
    
}

let genTest = buslinie();
genTest.next(); // hinein in die Funktion
genTest.next(42); // gehe zu "nach dem Yield"
let ergObj = genTest.next(42); // gehe zu "nach dem Yield"

console.log(ergObj.value)
