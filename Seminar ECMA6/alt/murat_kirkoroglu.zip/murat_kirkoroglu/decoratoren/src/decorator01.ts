
function MyDecorator(target){
    console.log("Ich dekoriere dann mal...", target);
    //
    //target.prototyoe.huhu = function(){
    //    console.log("ich bin huhu");
    //}
    return class extends target {
        constructor(...args){
            super(...args);
            this.toast = "das mist der toast";
        }
    };

}


@MyDecorator class Test {

    constructor(){
        this.test = "Das ist der Constructor";
    }

    hallo(){
            console.log("hi ich bin in der Klasse");
    }
}

let myTest = new Test("TESTParameter");
console.log("myTest", myTest);
myTest.hallo();

let myTest2 = new Test("TEST222Parameter");
console.log("myTest222", myTest2);
//myTest.hallo();

