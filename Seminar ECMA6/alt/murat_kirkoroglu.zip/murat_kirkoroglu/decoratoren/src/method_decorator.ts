

function MyMethodDecorator(target, arg, propDescr){
    console.log("Ich dekoriere eine Methode", target, arg, propDescr);
    // alte Methode speicchern
    let oldMethod = propDescr.value;

    let newMethod = function(arg){
        console.log("Ich bin die neu Methode:", this);
        //Wichtig: Kontext wieder einrichten
        oldMethod.call(this, arg);
    };

    return{
        value: newMethod,
        writable: false,
        enumerable: false,
        configurable: false
    };
}

class Test {
    constructor(derTest){
        this.test = derTest;
    }
    @MyMethodDecorator
    hallo(arg) {
        console.log("Hi! Ich bin die Klasse!", arg);
    }
}


let myTest = new Test("MURAT");

console.log("myTest", myTest);

console.log('\n');

myTest.hallo("Ich bin Cool...");

let newPrototype = myTest.hallo.prototype = ("Neues Prototype angelegt...");
console.log('\n');

console.log("newPrototype:", newPrototype);

