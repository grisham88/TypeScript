// Hier geht es um "destructuring"...

let zahlen = [1,2,3,4,5,];
console.log("Zahlen:", zahlen);

//let zahl1 = zahlen[0];

let [ zahl1 ] = zahlen;
console.log("Zahl1:", zahl1);

let chars = {
    a: "A",
    b: "B",
    c: "C",
    d: "D"
}

// let d = chars.a;
let { a, b: meinB, ...objRest } = chars;


console.log("a:", a);
console.log("b:", meinB);
console.log("objRst: ", typeof objRest);

let {...alleChars} = chars;
console.log("alleChars: ", alleChars);
