class Test{

    //Prolog schreiben mit Deklarationen
    testpotp: string;
    private testpotp2: string;
    public lieblingsBand = "Beatles";

    //Methods:
    constructor(testValue: string, testValue2: string, public testValue3?: string, private testValue4?: string){
        console.log(this);
        //Property
        this.testpotp = testValue;
        this.testpotp2 = testValue2;
    }


    test(){
        console.log("test:");
    }

    get tesprop2lesen(){
        return this.testpotp2;
    }


    addiere(a: number, b: number) :number{
        return a + b;
    }

}

var derTest = new Test("ALLES GUT", "Nochmal BESSER");

console.log("derTest:", derTest);
console.log("derTest.testpotp:", derTest.testpotp);
//console.log("derTest.testpotp:", derTest.testpotp2);

//
console.log("derTest.testpotp:", derTest.tesprop2lesen);


