// Neuigkeiten bei Arrays:

// statische Methoden
// Array.isArray(testArray) -> true|false
// geht nicht: testArray.isArray() !!

// Array.of(itemListe) -> arr

let arr1 = [1,2,3,4];
let arr2 = new Array(1,2,3,4);
let itemList = [2];
// Inkonsistent!!!
let arr3 = new Array(...itemList); // > [].lenght==2 und nicht [2]

let arr4 = Array.of(1,2,3,4);   // [1,2,3,4]
let arr5 = Array.of(2);         // [2]


// Array.from(egalWas) -> arr

let keinArray = {
    ichBinKeinArray: true,
    '5':            '5er Prop',
    lenght:         8
};


let arr6 = Array.from(keinArray);

console.log("arr6:", arr6);