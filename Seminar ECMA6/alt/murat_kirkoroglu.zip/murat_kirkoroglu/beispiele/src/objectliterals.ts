// Objektliterale

let nocheintest = "Noch ein Test";
let andererTest = "Andrerer Test";
let xKey = 'x';

// Symbol:
let mySymbol = Symbol();
console.log('mySymbol: ', mySymbol);
let myOtherSymbol = Symbol();
console.log('myOtherSymbol: ', myOtherSymbol);
console.log('myOtherSymbol===mySymbol: ', myOtherSymbol===mySymbol);

let drittesSymbol = Symbol('3. Symbol');
console.log('drittesSymbol: ', drittesSymbol);



let myObj = {
    test: "Ein Testprop",
    nocheintest: nocheintest,
    andererTest, // concise property definition
    hallo: function(){
        console.log('Bin das Objekt!');
    },
    [xKey]:  "Ein X-Test",
    // SymbolKey
    [mySymbol]: 'Das ist ein Symbol',
    // concise method definition
    hi(){
        console.log('Hi, ich bins!');
    } 
};

//myObj[xKey] = "Ein X-Test";

myObj.hi();


// mehrere Möglichkeiten

// myObj['x'] = "Ein X-Test";
//myObj.x = "Ein X-Test";

let dieKeys = Object.keys(myObj);
console.log("Object.keys:", dieKeys);

console.log(myObj[mySymbol]);

let dieSymbols = Object.getOwnPropertySymbols(myObj);
console.log("dieSymbols:", dieSymbols);