// Arrays und Iterables

let blumen = ["Rosen", "Tulpen", "Nelken"];

for(let i= 0; i < blumen.length; i++){
     console.log("for:", blumen[i]);   
};

blumen.forEach(val => console.log("foreach:", val));


for(let val of blumen){
    console.log("Schleife of:", val);
};

for(let char of 'Hallo'){
    console.log("Schleife of char:", char);
};

// Iterable: "Datensequnz im Rohzustand"
// Aus Iterables muss Iterator gebildet werden

// so geht das:
let blumenIterator = blumen.entries();
console.log("blumenIterator:", blumenIterator);


let valObj1 = blumenIterator.next();
console.log("valObj1:", valObj1);

let valObj2 = blumenIterator.next();
console.log("valObj2:", valObj2);

let valObj3 = blumenIterator.next();
console.log("valObj3:", valObj3);

let valObj4 = blumenIterator.next();
console.log("valObj4:", valObj4);

// nochmal...
let valObj5 = blumenIterator.next();
console.log("valObj5:", valObj5);