// Es gibt einen neuen Operator: ...

// Spread-Operator
let blumen = ["Rosen", "Tulpen", "Nelken"];

console.log(blumen);
// Array "ausbreiten" mit Spread-Operator: 

console.log(...blumen);

// String:
console.log(..."Hallo Blumen");
let blumen2 = ["Veilchen", "Geranien"];

//let blumen3 = blumen2.concat(blumen);
let blumen3 = ["Petunine", ...blumen, "Orchideen", ...blumen2];

console.log("Blumen3:", blumen3);
let blumen4 = [...blumen];
console.log("Blumen4:", blumen4);



// Rest-Operator

//function restTest(...args)
//console.log(Array.isArray(args));
//function restTest(a, b, c,...rest)
function restTest(a, b, c, d, e, ...rest){
    console.log(typeof arguments);
    //Array.prototype.forEach.call(arguments, function(arg){console.log("arg:", arg)});
    console.log(a, b, c, d, e);
    console.log(rest);
    console.log(Array.isArray(rest));
}

restTest(1,2,3,4,5,6,7,8);

