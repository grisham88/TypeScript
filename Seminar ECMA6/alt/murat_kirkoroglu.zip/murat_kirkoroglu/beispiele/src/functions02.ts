// function und arrow


function verdopple(x){
    console.log(arguments);
    return 2 * x;
}

//let zehn = verdopple(5);

// neue ArrowSyntax:
//let verdopple = (x) => 2 * x;

//let zwanzig = verdopple(10);
//console.log("zwanzig:",  zwanzig);