// functions

function addiere(a, b = 0){
    return a + b;
}

let erg = addiere(10,2);
console.log("erg:", erg);

erg = addiere(2);
console.log("erg:", erg);

function testAddierer(a: number, b: number): number{

    return a + b;
}    

let testErg = testAddierer(7, 7);

let falsch = testAddierer("7", "7");

console.log("erg:", erg);