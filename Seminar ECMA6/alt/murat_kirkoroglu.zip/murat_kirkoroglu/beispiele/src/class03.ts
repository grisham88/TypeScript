interface PersonenInterface{
    vorname: string;
    nachname?: string;
    hallo: () => void;
}

interface Saenger{
    stimmen: string;
    singen: () => void;
}

class Mensch{
    tanzen(){}
}

class MeinePerson implements PersonenInterface, Saenger, Mensch{

    constructor(public vorname: string, public stimmen: string){
    }

    hallo(){}
    singen(){}
    tanzen(){}
}