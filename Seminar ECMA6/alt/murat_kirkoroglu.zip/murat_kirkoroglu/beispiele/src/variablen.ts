// Es gibt neue Variablendeklarationen!

console.log("var a:", a);
console.log("let b:", b);

//alt:
var a = "A";

console.log("var a:", a);
{
    var a = "inneres A";
    console.log("inneres A:", a);
}

console.log("var a:", a);

// neu:
let b = "B";

console.log("let b:", b);

{
    let b = "inneres B";
    console.log("inneres B:", b);
}

console.log("let b:", b);

for(let i=0; i<3; i++){
    console.log("Schleife:", i)
}
console.log("danach Schleife:", i)

// neu: const

const c = 42;
console.log("const c: ", c);
    c = 43;
    console.log("const c: ", c);    