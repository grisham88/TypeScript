// implicit types

let test;
    test = "hallo";
    test = 42;
    test = true;

let test2 = "hallo2";
    //test2 = 42; // nope!
    test2 = "Welt";

// explicit types

let test3: string; // hier soll ein String rein. Den hab ich aber noch nicht...
    test3 = "aha!";

let test4: any;    
let test5: string = "Eigendlich rendundant!";    
// compound types
let test6: string | boolean = "Hallo";
    test6 = true; // ich WILL ABER auch ein Boolean ablegen dürfen!
