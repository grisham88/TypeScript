

//Strukturbeschreibung ("Literaler Typ")
let hans: {
    vorname: string;
    hallo: () => void;

};

// literal
hans = {
    vorname: "Hans",
    hallo(): void{
        console.log("Hallo!");
    }
    
}

let tom: {vorname: string; hallo: () => void;} = {
    vorname: "TIM",
    hallo: (){
        console.log("HEY TIM");
    }
}


interface PersonenInterface{
    vorname: string;
    nachname?: string;
    hallo: () => void;
}


//Strukturbeschreibung ("als bekannter Typ")
type PersonTyp = {
    vorname: string;
    hallo: () => void;    
}

let gustav: PersonTyp;
gustav = {
    vorname: "GUSTAVO",
    hallo: (){
        console.log("HEY");
    }    

};




class TsPerson{

    constructor(public vorname: string){
    }
    hallo(): void{
        console.log("Hallo!");
    }

}



let peter: TsPerson;
//peter = new TsPerson("PETER");

//peter.vorname = "NEXT";


let heinz = new TsPerson("Heinz");


let ingrid: PersonenInterface;
ingrid = {
    vorname: "INGRID",
    nachname: "Müller",
    hallo(){
        console.log("Hi INGRID!!!!");
    }

}

let TIM: PersonenInterface;
TIM = new TsPerson("BIM");