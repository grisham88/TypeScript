"use strict";
// Templates und Templateliterale
let myString = "Das ist ein String.";
let myString2 = "Das ist auch ein String.";
let myString3 = `Das heir ist auch einer!`; // geeignet für mehrzeilige Strings
let user = "Peter Panter";
let templ = `
    <div>
        <h1>User</h1>
        <h1> ${user} </h1>
    </div>
`;
console.log(templ);
user = "Leo Löwe";
console.log(templ);
function displayUser(user) {
    return `
    <div>
        <h1>User</h1>
        <h1> ${user} </h1>
    </div>    
    `;
}
let userDisplay = displayUser("Murat Kirkoroglu");
console.log(`das ist mein User ${userDisplay}. Cool`);
