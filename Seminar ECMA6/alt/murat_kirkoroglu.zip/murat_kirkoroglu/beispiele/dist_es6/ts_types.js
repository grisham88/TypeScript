"use strict";
// implicit types
let test;
test = "hallo";
test = 42;
test = true;
let test2 = "hallo2";
//test2 = 42; // nope!
test2 = "Welt";
// explicit types
let test3; // hier soll ein String rein. Den hab ich aber noch nicht...
test3 = "aha!";
let test4;
let test5 = "Eigendlich rendundant!";
// compound types
let test6 = "Hallo";
test6 = true; // ich WILL ABER auch ein Boolean ablegen dürfen!
