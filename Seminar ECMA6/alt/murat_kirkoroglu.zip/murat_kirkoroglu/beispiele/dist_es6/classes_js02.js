// Classes und Konstruktoren

function PersonenKonstruktor(){
    this.vorname = "Peter";
}


PersonenKonstruktor.prototype.hallo = function(){
    console.log(`hi, ich bin ${this.vorname}`);
}

PersonenKonstruktor.prototype.lieblindband = "Beatles";

let peter = new PersonenKonstruktor();
console.log("Peter:", peter);
peter.hallo();
//peter.lieblindband;

let lieblinsSymbol = Symbol();

class PersonenClass{
    // erzeugt INSTANZEIGRENSCHAFTEN
    constructor(nachname){
        console.log("Konstrukor");
        this.nachname = nachname;
        //Oooop. Wirklich? Ja, leider!
        this[lieblinsSymbol] = "IBO"
    }
    // ab hier: alles im Prototype ... Nur Methoden
    hallo(){
        console.log("ich bin HAns in der CLass");
    }

    // Accessor-Property
    get band(){
        return this[lieblinsSymbol];
    }
    set band(newBand){
        this[lieblinsSymbol] = newBand;
    }    

}

let person = new PersonenClass();

console.log("Hans-Lieblingsband:", person.band);







