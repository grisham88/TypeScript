"use strict";
// Hier geht es um "destructuring"...
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
let zahlen = [1, 2, 3, 4, 5,];
console.log("Zahlen:", zahlen);
//let zahl1 = zahlen[0];
let [zahl1] = zahlen;
console.log("Zahl1:", zahl1);
let chars = {
    a: "A",
    b: "B",
    c: "C",
    d: "D"
};
// let d = chars.a;
let { a, b: meinB } = chars, objRest = __rest(chars, ["a", "b"]);
console.log("a:", a);
console.log("b:", meinB);
console.log("objRst: ", typeof objRest);
let alleChars = __rest(chars, []);
console.log("alleChars: ", alleChars);
