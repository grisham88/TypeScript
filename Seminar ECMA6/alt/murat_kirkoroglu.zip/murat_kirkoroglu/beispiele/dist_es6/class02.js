"use strict";
//Strukturbeschreibung ("Literaler Typ")
let hans;
// literal
hans = {
    vorname: "Hans",
    hallo() {
        console.log("Hallo!");
    }
};
let tom = {
    vorname: "TIM",
    hallo: () => {
        console.log("HEY TIM");
    }
};
let gustav;
gustav = {
    vorname: "GUSTAVO",
    hallo: () => {
        console.log("HEY");
    }
};
class TsPerson {
    constructor(vorname) {
        this.vorname = vorname;
    }
    hallo() {
        console.log("Hallo!");
    }
}
let peter;
//peter = new TsPerson("PETER");
//peter.vorname = "NEXT";
let heinz = new TsPerson("Heinz");
let ingrid;
ingrid = {
    vorname: "INGRID",
    nachname: "Müller",
    hallo() {
        console.log("Hi INGRID!!!!");
    }
};
let TIM;
TIM = new TsPerson("BIM");
