"use strict";
class Test {
    //Methods:
    constructor(testValue, testValue2, testValue3, testValue4) {
        this.testValue3 = testValue3;
        this.testValue4 = testValue4;
        this.lieblingsBand = "Beatles";
        console.log(this);
        //Property
        this.testpotp = testValue;
        this.testpotp2 = testValue2;
    }
    test() {
        console.log("test:");
    }
    get tesprop2lesen() {
        return this.testpotp2;
    }
    addiere(a, b) {
        return a + b;
    }
}
var derTest = new Test("ALLES GUT", "Nochmal BESSER");
console.log("derTest:", derTest);
console.log("derTest.testpotp:", derTest.testpotp);
//console.log("derTest.testpotp:", derTest.testpotp2);
//
console.log("derTest.testpotp:", derTest.tesprop2lesen);
