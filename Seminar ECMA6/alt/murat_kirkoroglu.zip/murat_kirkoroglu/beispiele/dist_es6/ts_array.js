"use strict";
// Arrays in TypeScript
let myAnyArr = [];
let myArr = [2, 5];
let myImplicitAnyArray = [];
myImplicitAnyArray.push(12);
let myNumArray = [];
myNumArray.push(42);
// myNumArray.push('42'); // geht nicht, ist keine Number
let myNumBoolArray = [];
myNumBoolArray.push(17);
myNumBoolArray.push(true);
let durcheinander = [true, 'hey', 42];
