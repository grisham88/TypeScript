// Classes und Konstruktoren

function PersonenKonstruktor(){
    this.vorname = "Peter";
    //return this;
}


PersonenKonstruktor.prototype.hallo = function(){
    console.log(`hi, ich bin ${this.vorname}`);
}

PersonenKonstruktor.prototype.lieblindband = "Beatles";

let peter = new PersonenKonstruktor();

console.log("Peter:", peter);

peter.hallo();
peter.lieblindband;

class PersonenClass{

    // NICHT: das ist kein Code-Block
    // NICHT: das ist kein Objekt-Literal
    // GEHT: CONCISE METHODS dürfen erscheinen. NUR

    constructor(){
        console.log("Konstrukor");
    }


    // wird im Prototype abgelegt
    // Eigenschaft

    hallo(){
        console.log("ich bin HAns in der CLass");
    }

}

let hans = new PersonenClass();

console.log("Hans:", hans);

hans.hallo();
