"use strict";
class Mensch {
    tanzen() { }
}
class MeinePerson {
    constructor(vorname, stimmen) {
        this.vorname = vorname;
        this.stimmen = stimmen;
    }
    hallo() { }
    singen() { }
    tanzen() { }
}
