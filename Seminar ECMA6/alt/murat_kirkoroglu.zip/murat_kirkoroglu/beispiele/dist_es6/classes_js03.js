// Classes Und Konstruktoren : Vererbung


function FahrerFactory(){

    function Fahrer() {

    }

    Fahrer.prototype = 

}