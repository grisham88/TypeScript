// Arrays:
// sind Iterables
// haben entries()
// sind mit for-of zu verabeiten

let testdaten = [12,5,4,8,23,17,2,0,0,3,87,34,6];
console.log(testdaten);
// haben "higher order"-Methods:  higherOrderMethod(fn)
// als da wären: .forEach(), .some(), .every(), filter(), .map(), .reduce(), .reduceRight()
let gefiltert = testdaten.filter(item => item > 10);
console.log(gefiltert);
let gemappt = gefiltert.map(item => item*item);
console.log(gemappt);
let reduziert = gemappt.reduce((a, b) => a + b);
console.log(reduziert);