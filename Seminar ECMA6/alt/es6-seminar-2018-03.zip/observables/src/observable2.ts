// wir brauchen einen DOM-Knoten

// let btn:HTMLButtonElement | null = <HTMLButtonElement | null>document.getElementById('btn');
let btn :HTMLButtonElement = document.getElementById('btn') as HTMLButtonElement;

let btnObservable = Rx.Observable.fromEvent(btn, 'click');
btnObservable
.filter(evt => evt.clientX > 100)
.map(evt => `Klick an Position ${evt.clientX} px!`)
.subscribe(
    pos => console.log(pos)
);

// Inputstream:
let myinput: HTMLInputElement = document.getElementById('mytext') as HTMLInputElement;
let ausgabe: HTMLSpanElement = document.getElementById('ausgabe') as HTMLSpanElement;

let inputObservable = Rx.Observable.fromEvent(myinput, 'input');
inputObservable
// filtern auf der Zeitachse:
.debounceTime(300)
.subscribe(evt => {
    console.log(evt.target.value);
    ausgabe.innerHTML = evt.target.value;
});
