"use strict";
class Mensch {
    tanzen() { }
}
class Lebewesen {
    atmen() { }
}
class MeinePerson extends Lebewesen {
    constructor(vorname, stimme) {
        super();
        this.vorname = vorname;
        this.stimme = stimme;
    }
    hallo() { }
    singen() { }
    tanzen() { }
}
