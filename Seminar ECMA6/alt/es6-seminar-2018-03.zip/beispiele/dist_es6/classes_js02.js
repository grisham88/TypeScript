// Classes und Konstruktoren
"use strict";

function PersonKonstruktor(vorname) {
    this.vorname = vorname;
}
PersonKonstruktor.prototype.hallo = function(){
    console.log(`Hi, ich bin ${this.vorname}!`)
}
PersonKonstruktor.prototype.lieblingsband = "Beatles";

let peter = new PersonKonstruktor("Peter");
console.log("peter:", peter);
peter.hallo();
console.log("peter.lieblingsband:", peter.lieblingsband);

let lieblingsSymbol = Symbol();

class PersonClass {
    // erzeugt INSTANZEIGENSCHAFTEN
    constructor(vorname, geheimnis) {
        console.log("Konstruiere Person...", this);
        this.vorname = vorname;
        // Ooops. Wirklich? Ja, leider!
        // this._lieblingsessen = "Pizza";
        this[lieblingsSymbol] = "Pizza";
        // Propertydefinition (ECMA5) geht auch:
        let geheimnis = geheimnis;
        Object.defineProperty(this, 'geheim', {
            // Acccessor-Property
            set: function(newGeheim){
                geheimnis = newGeheim;
            },
            get: function(){
                return geheimnis;
            },
            enumerable: true,
            configurable: true
        });
    }
    // ab hier: alles im Prototype ... NUR Methods
    hallo(){
        console.log('Bin mit Class gemacht!');
    }
    // Accessor-Property: nur lesend:
    get lieblingsband() {
        console.log("Getter getriggert!", this);
        return "Beatles";
    }
    // Accessor-Property:  lesend UND schreibend:   
    get lieblingsessen() {
       // return this._lieblingsessen;
       return this[lieblingsSymbol];
    }
    set lieblingsessen(newEssen) {
        console.log("Setter getriggert!");
        // this._lieblingsessen = newEssen;
        this[lieblingsSymbol] = newEssen;
    }

}
console.log("typeof PersonClass: ",typeof PersonClass);

let hans = new PersonClass("Hans"); // ohne "new" geht nicht!

// let myObj = {};
// Object.defineProperty(myObj, 'name', {
//     // Acccessor-Property
//     set: function(){},
//     get: function(){},
//     enumerable: true,
//     configurable: true
// });
// console.log(myObj);


console.log("hans:", hans);

hans.hallo();
console.log("hans.lieblingsband:", hans.lieblingsband);
console.log(hans.lieblingsessen);
hans.lieblingsessen = "Pasta"; // ist jetzt okay!
console.log(hans.lieblingsessen);

