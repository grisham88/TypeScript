"use strict";
class Test {
    // Methods:
    constructor(testvalue, testvalue2, 
    // Property generieren:
    testprop3 = "Default", testprop4) {
        this.testprop3 = testprop3;
        this.testprop4 = testprop4;
        this.lieblingsband = "Beatles";
        console.log(this);
        this.testprop = testvalue;
        this._testprop2 = testvalue2;
    }
    test() {
        console.log("Test");
    }
    get testprop2() {
        return this._testprop2; // okay, darf ich mit PRIVATES
    }
    addiere(a, b) {
        return a + b;
    }
}
var derTest = new Test("Ein Test", "Test 2", "Kein Default");
console.log("derTest:", derTest);
console.log("derTest.testprop:", derTest.testprop);
// darf ich NICHT mit PRIVATE!!
// console.log("derTest._testprop2:", derTest._testprop2); 
// Zugriff auf PRIVATE durch Objekt-Methode ist okay
console.log("derTest.testprop2:", derTest.testprop2);
