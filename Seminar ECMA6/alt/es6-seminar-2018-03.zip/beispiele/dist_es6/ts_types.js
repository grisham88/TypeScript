"use strict";
// implicit types
let test;
test = "hallo";
test = 42;
test = true;
let test2 = "hallo";
// test2 = 42; // nope!
test = "welt";
// explicit types
let test3; // hier soll ein String rein. Den habe ich aber noch nicht...
test3 = "aha!";
// test3 = 42; // nope!
let test4;
let test5 = "Eigentlich redundant!";
// compound types
let test6 = "Hallo";
test6 = true; // ich WILL ABER auch ein Boolean ablegen dürfen!
let test7;
// spätere Änderung des Typs ist nicht möglich!
