"use strict";
// Hier geht es um "destructuring"...
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
let zahlen = [1, 2, 3, 4, 5, 6, 7];
console.log("zahlen:", zahlen);
// let zahl1 = zahlen[0];
let [zahl1, zahl2, , zahl4, ...rest] = zahlen;
console.log("zahl1:", zahl1);
console.log("zahl2:", zahl2);
console.log("zahl4:", zahl4);
console.log("rest:", rest);
let chars = {
    a: "A",
    b: "B",
    c: "C",
    d: "D"
};
// let a = chars.a;
let { a, c: meinC } = chars, objRest = __rest(chars, ["a", "c"]);
console.log("chars:", chars);
console.log("a:", a);
console.log("meinC:", meinC);
console.log("objRest:", objRest);
let alleChars = __rest(chars, []);
console.log("alleChars:", alleChars);
