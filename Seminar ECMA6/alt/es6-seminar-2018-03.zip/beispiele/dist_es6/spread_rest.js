"use strict";
// Es gibt einen neuen Operator: ...
// Spread-Operator:
let blumen = ["Rosen", "Tulpen", "Nelken"];
console.log(blumen);
// Array "ausbreiten" mit Spread-Operator:
console.log(...blumen);
let blumen2 = ["Veilchen", "Geranien"];
// let blumen3 = blumen2.concat(blumen);
let blumen3 = [
    "Petunien",
    ...blumen,
    "Orchideen",
    ...blumen2
];
console.log("blumen3", blumen3);
let blumen4 = [...blumen];
// String:
console.log(..."Hallo Welt");
let objXYZ = {
    x: "X",
    y: "Y",
    z: "Z"
};
console.log(objXYZ);
// Object "ausbreiten" mit Spread-Operator:
// console.log(...objXYZ); // wird später gehen!! (vielleicht)
// Rest-Operator
function restTest(...args) {
    console.log(typeof arguments);
    // Array.prototype.forEach.call(arguments, function(arg){ console.log("arg:", arg)});
    // console.log(a, b, c, d, e);
    console.log(Array.isArray(args));
}
restTest(1, 2, 3, 4, 5, 6, 7, 8);
