// Classes und Konstruktoren

function PersonKonstruktor(vorname) {
    this.vorname = vorname;
    // return this;
}
PersonKonstruktor.prototype.hallo = function(){
    console.log(`Hi, ich bin ${this.vorname}!`)
}
PersonKonstruktor.prototype.lieblingsband = "Beatles";

let peter = new PersonKonstruktor("Peter");
console.log("peter:", peter);
peter.hallo();

// Problem: Aufruf ohne "new" möglich...
// PersonKonstruktor();

class PersonClass {
    // NICHT: ein Code-Block!
    // lieblingsband = "Beatles"; // nope
    // NICHT: ein Object-Literal!
    // lieblingsband : "Beatles", // nope

    constructor(vorname) {
        console.log("Konstruiere Person...", this);
        this.vorname = vorname;
    }

    // was geht: CONCISE METHODS dürfen erscheinen!! NUR.
    // wird im Prototype abgelegt!!
    hallo(){
        console.log('Bin mit Class gemacht!');
    }
}
console.log("typeof PersonClass: ",typeof PersonClass);

let hans = new PersonClass("Hans"); // ohne "new" geht nicht!
// console.log(typeof PersonClass.prototype.hallo);

console.log("hans:", hans);

hans.hallo();
