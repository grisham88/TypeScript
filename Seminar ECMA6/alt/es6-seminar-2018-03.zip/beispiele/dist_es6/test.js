"use strict";
console.log("Hallo Welt!");
