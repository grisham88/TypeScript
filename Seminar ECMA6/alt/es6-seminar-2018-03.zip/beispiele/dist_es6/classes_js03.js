// Classes und Konstruktoren: Vererbung
"use strict";

function PersonKonstruktor(vorname) {
    this.vorname = vorname;
}
PersonKonstruktor.prototype.hallo = function(){
    console.log(`Hi, ich bin ${this.vorname}!`)
}
PersonKonstruktor.prototype.lieblingsband = "Beatles";

let peter = new PersonKonstruktor("Peter");
console.log("peter:", peter);
peter.hallo();
console.log("peter.lieblingsband:", peter.lieblingsband);

// "erbt" von PersonKonstruktor:
function FahrerFactory(vorname, auto) {
    function Fahrer() {
        this.auto = auto;
    }
    Fahrer.prototype = new PersonKonstruktor(vorname);
    return new Fahrer();
}
let klaus = FahrerFactory("Klaus","BMW");

// jetzt wird alles gut!

class PersonClass {
    // erzeugt INSTANZEIGENSCHAFTEN
    constructor(vorname) {
        this.vorname = vorname;
    }
    // ab hier: alles im Prototype ... NUR Methods
    hallo(){
        console.log('Bin mit Class gemacht!');
    }
    // Accessor-Property: nur lesend:
    get lieblingsband() {
        console.log("Getter getriggert!", this);
        return "Beatles";
    }
}

let hans = new PersonClass("Hans"); // ohne "new" geht nicht!
console.log("hans:", hans);

class FahrerClass extends PersonClass {
    constructor(vorname, auto) {
        // müssen wir:
        super(vorname); // -> wegen: return this
        this.auto = auto
    }
    fahren() {
        console.log("Ich fahre ", this.auto);
    }
}

let heinz = new FahrerClass("Heinz","BMW");
console.log("FahrerClass:", heinz)
heinz.hallo();





