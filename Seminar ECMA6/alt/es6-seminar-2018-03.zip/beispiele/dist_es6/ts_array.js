"use strict";
// Arrays in TypeScript:
let myAnyArr = [];
let myImpicitAnyArray = [];
myImpicitAnyArray.push(12); // nimmt alles
let myArr = [2, 5]; // automatisch number[] !!
let myNumArray = [];
myNumArray.push(42); // geht
// myNumArray.push('Hey'); // geht nicht
let myNumBoolArray = [];
myNumBoolArray.push(17);
myNumBoolArray.push(false);
let durcheinander = [true, 'hey', 42];
