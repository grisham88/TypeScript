"use strict";
// Strukturbeschreibung ("literaler Typ")
let hans;
hans = {
    vorname: "Hans",
    hallo() {
        console.log("Hallo");
    }
};
// alles auf einmal
let tom = {
    vorname: "Tom",
    hallo() {
        console.log("Hallo");
    }
};
let gustav;
gustav = {
    vorname: "Gustav",
    hallo() {
        console.log("Hey");
    }
};
class TsPerson {
    constructor(vorname) {
        this.vorname = vorname;
    }
    hallo() {
        console.log("Hallo!");
    }
}
// eine Class IST ein Typ!!
let peter;
peter = {
    vorname: "Peter",
    hallo() {
        console.log("Egal");
    }
};
let heinz = new TsPerson("Heinz");
heinz.hallo();
let ingrid;
ingrid = {
    vorname: "Ingrid",
    hallo() { },
    nachname: ""
};
let tim;
tim = new TsPerson("Tim");
