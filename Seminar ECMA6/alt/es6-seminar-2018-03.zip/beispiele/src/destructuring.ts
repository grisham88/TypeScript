// Hier geht es um "destructuring"...

let zahlen = [1,2,3,4,5,6,7];
console.log("zahlen:", zahlen);
// let zahl1 = zahlen[0];

let [ zahl1, zahl2, , zahl4, ...rest ] = zahlen;
console.log("zahl1:", zahl1);
console.log("zahl2:", zahl2);
console.log("zahl4:", zahl4);
console.log("rest:", rest);

let chars = {
    a:"A", 
    b:"B", 
    c:"C",
    d:"D"
}

// let a = chars.a;
let { a, c: meinC, ...objRest } = chars;

console.log("chars:", chars);

console.log("a:", a);
console.log("meinC:", meinC);

console.log("objRest:", objRest);

let {...alleChars} = chars;
console.log("alleChars:", alleChars);