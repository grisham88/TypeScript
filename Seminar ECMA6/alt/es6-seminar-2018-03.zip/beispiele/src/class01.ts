class Test {
    // Prolog mit Deklarationen
    testprop: string;
    private _testprop2: string;
    public lieblingsband = "Beatles";

    // Methods:
    constructor(
        testvalue: string,
        testvalue2: string,
        // Property generieren:
        public testprop3:string = "Default",
        private testprop4?: string
    ){
        console.log(this);
        this.testprop = testvalue;
        this._testprop2 = testvalue2;
    }
    test() {
        console.log("Test");
    }
    get testprop2(){
        return this._testprop2; // okay, darf ich mit PRIVATES
    }
    addiere(a: number, b: number) :number {
        return a + b;
    }
}

var derTest = new Test("Ein Test","Test 2", "Kein Default");
console.log("derTest:", derTest);
console.log("derTest.testprop:", derTest.testprop);
// darf ich NICHT mit PRIVATE!!
// console.log("derTest._testprop2:", derTest._testprop2); 
// Zugriff auf PRIVATE durch Objekt-Methode ist okay
console.log("derTest.testprop2:", derTest.testprop2); 
