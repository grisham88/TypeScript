interface PersonInterface {
    vorname:string;
    nachname?:string;
    hallo: () => void;
}

interface Saenger {
    stimme:string;
    singen: () => void;
}
// würde ich nicht für "Implements" verwenden!
type PersonType2 = {
    vorname:string;
    hallo: () => void;
};

class Mensch {
    tanzen() {}
}

class Lebewesen {
    atmen(){}
}

class MeinePerson extends Lebewesen implements Mensch, PersonInterface, Saenger {
    constructor(public vorname:string, public stimme:string){
        super();
    }
    hallo(){}
    singen(){}
    tanzen() {}
}


