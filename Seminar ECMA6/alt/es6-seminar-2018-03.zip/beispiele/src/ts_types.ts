// implicit types
let test;
    test = "hallo";
    test = 42;
    test = true;

let test2 = "hallo";
    // test2 = 42; // nope!
    test = "welt";

// explicit types
let test3: string;  // hier soll ein String rein. Den habe ich aber noch nicht...
    test3 = "aha!";
    // test3 = 42; // nope!

let test4: any;
let test5: string = "Eigentlich redundant!";

// compound types
let test6: string | boolean = "Hallo";
    test6 = true; // ich WILL ABER auch ein Boolean ablegen dürfen!

let test7:any;
// spätere Änderung des Typs ist nicht möglich!
 