// Objektliterale und Symbols

let nocheintest = "Noch ein Test";
let anderertest = "Anderer Test";
let xKey = 'x'; // Stringkey

// Symbols:
let mySymbol = Symbol();
console.log("mySymbol:", mySymbol);
let myOtherSymbol = Symbol();
console.log("myOtherSymbol:", myOtherSymbol);
console.log("mySymbol===myOtherSymbol:", mySymbol===myOtherSymbol);

let drittesSymbol = Symbol('3. Symbol');
console.log("drittesSymbol:", drittesSymbol);

let myObj = {
    test: "Ein Testprop",
    'nocheintest': nocheintest,
    // concise property:
    anderertest, 
    hallo: function() {
        console.log('Bin das Objekt!');
    },
    // computed key:
    [xKey]:"Ein X-Test",
    // Symbolkey:
    [mySymbol]: 'Das ist ein Symbolprop',
    // concise method:
    hi() {
        console.log("Hi, ich bin's!");
    }
}; 

let dieKeys = Object.keys(myObj);
console.log("Object.keys(myObj):", dieKeys);
console.log(myObj[mySymbol]);
let dieSymbols = Object.getOwnPropertySymbols(myObj);
console.log("Object.getOwnPropertySymbols(myObj):", dieSymbols);




