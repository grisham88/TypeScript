// Arrays in TypeScript:

let myAnyArr: any[] = [];

let myImpicitAnyArray = [];
myImpicitAnyArray.push(12); // nimmt alles

let myArr = [2, 5];  // automatisch number[] !!

let myNumArray: number[] = [];
myNumArray.push(42); // geht
// myNumArray.push('Hey'); // geht nicht

let myNumBoolArray: (number|boolean)[] = [];
myNumBoolArray.push(17);
myNumBoolArray.push(false);

let durcheinander = [true, 'hey', 42]

