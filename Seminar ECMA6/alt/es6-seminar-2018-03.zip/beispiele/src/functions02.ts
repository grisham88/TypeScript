// function und arrow



let verdopple = function(x) {
    console.log("this:", this);
    console.log(arguments); // { '0': 5 }
    return 2 * x;
};

let zehn = verdopple(5);

let verdoppler = {
    verdopple: verdopple
};

let acht = verdoppler.verdopple(4);

// neue ArrowSyntax:

// let verdoppleArr = x => 2 * x;

let verdoppleArr = (x) => { 
    console.log("arrThis:", this);
    // arguments EXISTIERT nicht!!!
    return  2 * x;
};

let zwanzig = verdoppleArr(10);
console.log(zwanzig);

verdoppler.verdoppleArr = verdoppleArr;

let zwoelf = verdoppler.verdoppleArr(6);

let testArrow = (a:number, b:number):number  => {
    return a + b
}

[1,2,3,4].forEach(val => console.log(val));

function bla() {}


// bla(); // this ist window (im Browser)
// o.bla(); // this ist o

// bla.call(obj2, arg1, arg2, arg3); // soll auf obj2 arbeiten!
// bla.apply(obj3, [arg1, arg2, arg3]); // auf obj3
// let newBla = bla.bind(obj4);


let obj5 = {
    x:"X",
    meth: function(){
        console.log(this.x);

        let that = this;

        function innen() {
            // console.log(this.x);
            console.log("innen:",that.x);
        }
        innen();

        let innenArr = () => {
            console.log("innenArr:",this.x); // nu?
        }
        innenArr();
    }
}

obj5.meth();





