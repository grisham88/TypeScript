// Strukturbeschreibung ("literaler Typ")
let hans: {
    vorname:string;
    hallo: () => void;
};

hans = {
    vorname: "Hans",
    hallo() {
        console.log("Hallo");
    }
};
// alles auf einmal
let tom: { vorname:string; hallo: () => void } = {
    vorname: "Tom",
    hallo() {
        console.log("Hallo");
    }
};

// Strukturbeschreibung als benannter Type:
type PersonType = {
    vorname:string;
    hallo: () => void;
};

let gustav: PersonType;
gustav = {
    vorname: "Gustav",
    hallo() {
        console.log("Hey");
    }
};


interface PersonInterface {
    vorname:string;
    nachname?:string;
    hallo: () => void;
}

class TsPerson {

    constructor(public vorname:string) {    
    }
    hallo(): void {
        console.log("Hallo!")
    }
}

// eine Class IST ein Typ!!
let peter: TsPerson;
peter = {
    vorname: "Peter",
    hallo() {
        console.log("Egal")
    }
};

let heinz = new TsPerson("Heinz");
heinz.hallo();

let ingrid: PersonInterface;
ingrid = {
    vorname:"Ingrid",
    hallo(){},
    nachname:""
}

let tim: PersonInterface;
tim = new TsPerson("Tim");