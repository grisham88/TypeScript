// Es gibt neue Variablendeklarationen!!

// console.log("var a: ", a); // kein Fehler, aber naja...
// console.log("let b: ", b); // TDZ !!! ERROR!!


// alt:
var a = "A";
console.log("var a: ", a);
{
    var a = "Inneres A";
    console.log("var a: ", a);
}
console.log("var a: ", a);

// neu:  let
let b = "B";
console.log("let b: ", b);
{
    let b = "Inneres B";
    console.log("let b: ", b);
}
console.log("let b: ", b);

for(let i = 0; i<3; i++) {
    console.log("Schleife: ", i);
    var temp;
}
// console.log("i nach der Schleife: ", i); // TDZ !!!

// neu: const
const c = 42;
console.log("const c: ", c);
    //  c = 43; // Neuzuweisung NICHT möglich!

const globaleFunktion = function() {};
const speicher = [];