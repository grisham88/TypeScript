// Templates und Templateliterale

let myString = "Das ist ein String.";
let myString2 = 'Das ist auch ein String.';

let myString3 = `Das hier ist auch einer!`;

let user = "Peter Panter";

let templ = `
    <div>
        <h1>User</h1>
        <p> ${user} </p>
    </div>
`;

console.log(templ);

user = "Leo Löwe";

console.log(templ);

function displayUser(user) {
    return `
        <div>
            <h1>User</h1>
            <p> ${user} </p>
        </div>
    `;
}

let userDisplay = displayUser('Leo Löwe');
console.log(`Das ist mein User: ${userDisplay}. Cool!`);