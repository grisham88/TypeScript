

function addiere(a, b = 0) {
   // b = b | 0;
    return a + b;
}

let erg = addiere(5,7);
    console.log("erg:", erg);
    erg = addiere(9);
    console.log("erg:", erg);


function testAddierer(a:number, b:number) :number {
    return a + b;
}

let testErg = testAddierer(7, 7);

let falsch = testAddierer(12,8);

function testAddierer2(a:number, b?:number) :number {
    b = b ? b : 0;
    return a + b;
}

let eineZahl = testAddierer2(8);