// Promise/A

let prom = new Promise(function(resolve, reject){
    console.log("Läuft...", arguments);
    // Promise ist "pending" (1. Zustand)

    // HIER starte ich den asynchronen Vorgang:
        let req = new XMLHttpRequest();
        req.open('get','../data/personen.json',true);
        req.onload = function(){
            if(this.readyState===4) {
               // hier Promise resolven:
               resolve(this.responseText);
            }
        }
        req.onerror = function(){
            reject('Ging schief'); 
        }
        req.send();  // Daten angefordert

    // Prozess ERFOLGREICH beendet:
    // setTimeout(() => {
    //     resolve(42);
    // }, 2000);
     // Promise ist "resolved"
    // Prozess NICHT erfolgreich:
    // reject('Ging schief'); // Promise ist "rejected"



});

// Callback ans Promise binden:
prom.then(
    // Success:
    function(response){
        console.log("response: ",response);
    },
    // ERROR:
    function(err){
        console.log("Wir haben einen Ooops...", err);
    }
);


prom.then(function(response){
    console.log("Callback 2: ",response);
}, function(){
    console.log("Ooops");
});

// viel später: 
setTimeout(() => {
    prom.then(function(response){
        console.log("Callback 3 nach 5 Sekunden: ",response);
    }, function(){
        console.log("Ooops nach 5 Sekunden");
    });
}, 5000);