// 3 Dinge brauchen wir
// a) Sequenz, also die Generatorfunction
// b) einen Funktion (Ajaxer), die den Request 
//    durchführt
// c) eine Funktion (Ajaxrunnner), die zwischen 
//    Ajaxer und Generator vermittelt

function * ajaxSequenz() {
    // mehrere Calls sollen abgesetzt werden:
   let response;
   try {
        response =  yield ajaxRunner('../data/joe.json');
        console.log(response);
    } catch(err) {
            console.error(err);
    }
    try {
        response =  yield ajaxRunner('../_data/gerda.json');
        console.log(response);
    } catch(err) {
        console.error(err);
    }
    try {  
        response =  yield ajaxRunner('../data/karl.json');
        console.log(response);
    } catch(err) {
        console.error(err);
    }
    try { 
        response =  yield ajaxRunner('../data/heinrich.json');
        console.log(response);
    } catch(err) {
        console.error(err);
    }
}

let mySequenz = ajaxSequenz();

function ajaxer(url: string, cb: Function) {
    // führt Call durch
    // bildet XMLHttpRequest
    // hier brauche ich einen CB
    let call = new XMLHttpRequest();
    call.open('get', url, true);
    // Type Assertion:
    call.onload = <(this:XMLHttpRequest, e:Event) => void>cb;
    call.send();
}

function ajaxRunner(url: string) {
    // console.log("Ajaxrunner!");
    // bildet den Callback
    // beauftragt den Call mit URL und CB
    ajaxer(url, function(this:XMLHttpRequest, e:Event){
        if(this.status < 400) {
            // benachrichtigt Generator mySequenz
            mySequenz.next(this.responseText);
        } else {
            if(mySequenz.throw) {
                mySequenz.throw(new Error('Ressource nicht verfügbar'));
            }
            
        }
    });
}

// Starten:
mySequenz.next();