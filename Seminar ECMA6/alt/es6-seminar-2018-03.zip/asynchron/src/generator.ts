let arr = [1,2,3,4];
let iterator = arr.entries();
// Valueobject:
let iteratorValue1 = iterator.next();
console.log("iteratorValue1", iteratorValue1);

// entspricht den Iterable
function * anweisungen(): IterableIterator<number> {
    console.log("Tu dies");
    yield 17; // hier mal anhalten und Wert ausgeben...
    console.log("Tu das");
    yield 18; // hier mal anhalten...
    console.log("Tu jenes");
    yield 19; // hier mal anhalten...
    console.log("Tu noch was");
    return 42;
}

let myGenerator = anweisungen();
let genValue1 = myGenerator.next();
console.log("genValue1: ", genValue1);
let genValue2 =  myGenerator.next();
console.log("genValue2: ", genValue2);
let genValue3 =  myGenerator.next();
console.log("genValue3: ", genValue3);
let genValue4 =  myGenerator.next();
console.log("genValue4: ", genValue4);
let genValue5 =  myGenerator.next();
console.log("genValue5: ", genValue5);

let myGenerator2 = anweisungen();
for(let val of myGenerator2) {
    console.log("for-of:",val)
}

