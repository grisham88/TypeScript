// Ajax-Request:
let req = new XMLHttpRequest();
req.open('get','../data/personen.json',true);

// Callback binden VOR Abschicken
req.onload = function(){
    // was ist this? req
    if(this.readyState===4) {
        console.log("Daten", this.responseText);
    }
}
// Abschicken
req.send();  // Daten angefordert

// ... Daten sind da ?