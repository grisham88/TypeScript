function * buslinie() {
    console.log("Vor dem Yield");
    let zahl = yield; // <-----X
    console.log("Nach dem Yield: ", zahl);
    let zahl2 = yield; // <--- Y
    console.log("Nach dem 2. Yield: ", zahl2);
    return zahl + zahl2;
}

let genTest = buslinie();

genTest.next(); // hinein in die Funktion zu X
genTest.next(42); // gehe zu "nach dem Yield" (1. Zahl)
let ergObj = genTest.next(17);
console.log(ergObj.value)

