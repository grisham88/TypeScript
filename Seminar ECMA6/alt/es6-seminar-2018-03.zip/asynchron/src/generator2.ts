// Ich brauche Zahlen ...
let sequenz = [2,4,8,16,32,64]

function * zahlenreihe(){
    let n = 2;
    while(true) {
        yield n;
        n = n * 2;
        // Abbruchbedingung:
        if(n > 100000000) {
            return;
        }
    }
}

let dieZahlen = zahlenreihe();

let zahl1 = dieZahlen.next(); // Start!
console.log(zahl1);
let zahl2 = dieZahlen.next(); // Start!
console.log(zahl2);

let mehrZahlen = zahlenreihe();
for(let zahl of mehrZahlen) {
    console.log(zahl);
}
