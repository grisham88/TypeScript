function MyMethodDecorator(target, key, propDescr) {
    console.log("Ich dekoriere eine Methode!", target, key, propDescr);
    // alte Methode speichern. Kontext geht JETZT verloren.
    let oldMethod = propDescr.value;
    // Neue Ersatzmethode erstellen:
    let newMethod = function(...args){
        console.log('Ich bin die neue Methode: ', this);
        // Wichtig: Kontext wieder einrichten
        oldMethod.call(this, ...args);
    };
    // Es wird ein Descriptor zurückgegeben:
    return {
        value: newMethod,
        writable: false,
        enumerable: false,
        configurable: false
    };
}


class Test {
    constructor(derTest){
        this.test = derTest;
    }
    @MyMethodDecorator
    hallo(arg) {
        console.log("Hi! Ich bin die Klasse!", this);
    }
}

let myTest = new Test('Teste Method-Decorator');
myTest.hallo('Cool!');

