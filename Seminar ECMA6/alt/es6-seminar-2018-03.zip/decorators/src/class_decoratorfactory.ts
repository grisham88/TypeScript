function MyClassDecoratorFactory(conf) {

    return function (target) {
        // wir returnen eine Class
        return class extends target {
            constructor(...args) {
                super(...args);
                this.toast = conf.toastbelag;
            }
            hallo(arg) {
                console.log(conf.message, arg);
                let erg = arg * conf.faktor;
                super.hallo(erg); // hier wird sie "Huckepack" aufgerufen
            }
            
        };
    };

}



@MyClassDecoratorFactory({
    faktor:3,
    message:'Ich bin ein String aus der Konfiguration',
    toastbelag: 'Butter und Marmelade'
}) 
class Test {
    constructor(derTest){
        this.test = derTest;
    }
    hallo(arg) {
        console.log("Hi! Ich bin die Klasse!", arg);
    }
}

let myTest = new Test("Das ist ein Testparameter");
console.log(myTest);
myTest.hallo(42);
