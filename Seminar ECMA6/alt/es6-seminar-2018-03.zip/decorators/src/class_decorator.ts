function MyDecorator(target) {
    console.log("Ich dekorier dann mal...", target);
    // Don't do that at home:
    // target.prototype.huhu = function(){
    //     console.log('Da könnte ja jeder kommen!');
    // }
    // wir returnen: nichts ... oder: eine Class
    return class extends target {
        constructor(...args) {
            super(...args);
            this.toast = "Trocken";
            // KÖNNTE: Prop der Superklasse überschreiben
            // this.test = "Das ist jetzt MEIN Test";
        }
        // verdeckt die gleichnamige Methode der Superklasse!
        hallo(arg) {
            // KÖNNTE: Argument abfangen
            console.log("Hi! Ich bin der Decorator!", arg);
            //... modifizieren
            let erg = arg * 2;
            // ... und weitergeben
            super.hallo(erg); // hier wird sie "Huckepack" aufgerufen
        }
        huhu(){
            console.log('Da könnte ja jeder kommen!');
        }
    };
}

@MyDecorator 
class Test {
    constructor(derTest){
        this.test = derTest;
    }
    hallo(arg) {
        console.log("Hi! Ich bin die Klasse!", arg);
    }
}

let myTest = new Test("Das ist ein Testparameter");
console.log(myTest);
myTest.hallo(42);

let myTest2 = new Test("Ich bin dann mal weg...");
myTest2.huhu();