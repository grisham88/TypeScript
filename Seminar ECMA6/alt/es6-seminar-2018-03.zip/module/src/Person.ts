export class Person {
    constructor(public vorname:string) {  }
    hallo() {
        console.log("Hallo, ich bin ", this.vorname,"!");
    }
}