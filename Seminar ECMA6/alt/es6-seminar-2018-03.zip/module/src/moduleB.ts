import { a, objX, blumen, speicherA, liesSpeicherA } from './moduleA';

console.log(a)

let dasX = objX.x;
console.log(dasX);

let speicher = {
    write: speicherA,
    read: liesSpeicherA
}

export { speicher }