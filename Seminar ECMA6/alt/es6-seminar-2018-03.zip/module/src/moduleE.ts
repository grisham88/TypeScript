// Import eines Defaultexports (Name frei wählbar!):
import toolObj from './moduleD';

// Pauschaler Import "von allem"
import * as boxA from './moduleA';

console.log(toolObj);

console.log(boxA);
