import { Fahrer } from "./Fahrer";

console.log("Hallo, ich bin MAIN! Ich starte jetzt...");

let peter = new Fahrer("Peter");

peter.hallo();
peter.fahren();

