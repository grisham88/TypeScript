// Das ist Modul A
// "use strict"; // nicht nötig! ES6-Module sind IMMER strict!

let a = "Das ist ein A aus Modul A";
let b = "Ich bleibe hier";
let c = "Ich auch.";

// geht auch zwischendrin:
export let blumen = ["Rosen", "Tulpen", "Nelken"];

let objX = {
    x: "Modul A hat ein X"
}
function aTest() {
    console.log("Test Functionexport aus Modul A");
}

let speicher = [];

function speicherA(item) {
    speicher.push(item);
}
function liesSpeicherA() {
    return [...speicher];
}

// benannter Export
export { a, objX, aTest, speicherA, liesSpeicherA}




// function test() {
//     let b = "B"
//     export { b } // NEIN! Export muss TOPLEVEL sein
// }