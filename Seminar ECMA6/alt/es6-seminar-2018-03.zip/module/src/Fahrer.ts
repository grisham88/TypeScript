import { Person } from "./Person";

export class Fahrer extends Person {
    constructor(...args) {
        super(...args);
    }
    fahren() {
        console.log("Fahre BMW...");
    }
}