import { speicher as derSpeicher } from './moduleB';

let speicher = {
    super:"Toll"
}

console.log(derSpeicher);
derSpeicher.write(17);
derSpeicher.write(32);
derSpeicher.write(15);
derSpeicher.write(8);
console.log(derSpeicher.read());