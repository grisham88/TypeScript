// exportiert 2 Funktionen
var LN2 = Math.LN2;
var LN10 = Math.LN10;

function getLN2() {
    return LN2;
}

function getLN10() {
    return LN10;
}

export { getLN2, getLN10 };