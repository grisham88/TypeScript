"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var cos = Math.cos;
var sin = Math.sin;
function getCos(val) {
    return cos(val);
}
exports.getCos = getCos;
function getSin(val) {
    return sin(val);
}
exports.getSin = getSin;
//# sourceMappingURL=trigonometry.js.map