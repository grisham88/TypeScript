// was soll er tun?
import {blattSumme} from './blattSumme.module';
import {karteGeben} from './dealer';

export let blatt = []; 

function karteVerlangen() {
   console.log("Player verlangt Karte");
  // karteGeben();
}

function blattBetrachten() {

}

function spielBeenden() {

}

function blattUpdatePlayer() {
    return blattSumme(blatt);
}

export {
    karteVerlangen,
    blattBetrachten,
    spielBeenden,
    blattUpdatePlayer
}