export abstract class Mensch {
    constructor() {

    }
    abstract singen() :void
}