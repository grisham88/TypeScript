import { Mensch } from './Mensch';
export class Person extends Mensch {
    name:string;

    constructor(name) {
        super();
        this.name = name;
    }
    hallo() {
        console.log(`Hallo, ich bin  ${this.name} !`)
    }
    singen() {
        console.log("la la la");
    }
}