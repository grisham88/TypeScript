import { Person } from './Person';
import { Auto } from './interfaces/Auto';

export  class Fahrer extends Person {
    fuehrerschein:string;
    auto:Auto;
    constructor(name, klasse, auto:Auto) {
        super(name);
        this.fuehrerschein = klasse;
        this.auto = auto
    }
    hallo() {
        super.hallo();
        console.log(`Ich fahre einen ${this.auto.marke} mit ${this.auto.ps} PS. Brumm brumm!.`)
    }

}