export function myClassDecorator(c) : any  {
    console.log("Class-Decorator aufgerufen!");
    console.log(c);

    c.prototype.test = "Ein Test";
    Object.defineProperty(c.prototype, 'test2', {
        value:"Noch ein Test",
        writable:true,
        enumerable:true,
        configurable:true
    });

    let oldC = c;
    let newC = function() {
        console.log("Before");
        oldC.apply(this, arguments); // alten Konstruktor anwenden!
        console.log("After");
        this.foo = "Bar";
    }
    // ... und den Prototype retten!
    newC.prototype = oldC.prototype;
    return newC;
}