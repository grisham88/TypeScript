export function myAccessorDecorator(a,b,c) : any {
    console.log("Accessor-Decorator aufgerufen", arguments.length , "Argumente")
    console.log("1. Arg:",  a); // Prototype für Method-Param, constructor für constructor
    console.log("2. Arg:",  b); // MethodName (undefined für constructor!)
    console.log("3. Arg:",  c); // Index d. Params  
    let localTitle = 'Doktor';
    return { 
        enumerable:false, 
        get: function() { return localTitle; },
        set: function(newTitle) {
            localTitle = newTitle;
        }
    };
}