export function myMethodDecorator(a, b, c) : any {
    console.log("MethodDecorator aufgerufen:", arguments.length, "Argumente.");
    // console.log(a); // class
    // console.log(b); // methodName
    console.log("3. Arg:", c); // Propdefinition ... brauchen wir!
    let oldMethod = c.value;
    let newMethod = function() {
        console.log("Decorated Method: Before-Aspect");
        oldMethod.apply(this, arguments);
        console.log("Decorated Method: After-Aspect");
    }
    return {value:newMethod, writable:false, enumerable:true, configurable:false};
}