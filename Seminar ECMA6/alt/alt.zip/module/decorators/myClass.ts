import {myClassDecorator} from './myClassDecorator';
import {myMethodDecorator} from './myMethodDecorator';
import {myPropertyDecorator} from './myPropertyDecorator';
import {myParamDecorator} from './myParamDecorator';
import {myAccessorDecorator} from './myAccessorDecorator';

@myClassDecorator
export class MyClass {
    @myPropertyDecorator public dekor;
    name:string;
    constructor(theName: string) {
        console.log("Instanz myClass erzeugt!");
        this.name = theName;
    }
    @myMethodDecorator 
    hallo(@myParamDecorator  msg) {
        console.log(`Hallo, ich bin ${this.title} ${this.name}. ${msg}`)
    }
    @myAccessorDecorator
    get title(){
        return "Professor";
    }
}