function cos() {
    
    }
    
function sin(){}
    
export {cos, sin }