import * as logarythm from './logarythm';
import * as trigonometry from './trigonometry';
console.log(logarythm);
console.log(trigonometry);

export {logarythm, trigonometry};
