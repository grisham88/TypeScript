import { Person } from './Person';
export class Fahrer extends Person {
    constructor(name, klasse, auto) {
        super(name);
        this.fuehrerschein = klasse;
        this.auto = auto;
    }
    hallo() {
        super.hallo();
        console.log(`Ich fahre einen ${this.auto.marke} mit ${this.auto.ps} PS. Brumm brumm!.`);
    }
}
