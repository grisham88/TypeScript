export function myPropertyDecorator() {
    console.log("Property-Decorator aufgerufen", arguments.length, "Argumente.");
}
