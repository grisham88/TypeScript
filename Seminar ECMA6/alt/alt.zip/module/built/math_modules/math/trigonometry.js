var cos = Math.cos;
var sin = Math.sin;
function getCos(val) {
    return cos(val);
}
function getSin(val) {
    return sin(val);
}
export { getCos, getSin };
