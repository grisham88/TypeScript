// Fasst die beiden Submodule zusammen:
import * as trigonometry from './math/trigonometry';
import * as logarithm from './math/logarithm';
export { trigonometry, logarithm };
