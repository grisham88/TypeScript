// Die App...
import { trigonometry } from './math';

console.log("Hallo, ich bin die App!");
console.log("Ich kann rechnen...");
let sin = trigonometry.getSin(5);
console.log("Der Sinus von 5 ist: , ", sin);
