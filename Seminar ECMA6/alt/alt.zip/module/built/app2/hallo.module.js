export let hallo = function (name) {
    alert("Hallo " + name + "!");
};
