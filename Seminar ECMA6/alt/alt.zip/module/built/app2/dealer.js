// Dealer:
import { blatt as playerBlatt } from './player';
import { blattSumme } from './blattSumme.module';
let blatt = [];
function wertErmitteln() {
    let number = Math.ceil(Math.random() * 11) + 1;
    console.log(number);
    return number;
}
function karteGeben(who) {
    console.log("Dealer gibt Karte!");
    if (who == "dealer") {
        blatt.push(wertErmitteln());
    }
    if (who == "player") {
        playerBlatt.push(wertErmitteln());
    }
    console.log(blatt);
    console.log(playerBlatt);
    // Karte an Spieler
    // eigenes Blatt betrachten
    // ggf. busted()
}
function busted() {
}
function blattUpdateDealer() {
    return blattSumme(blatt);
}
export { karteGeben, blattUpdateDealer };
