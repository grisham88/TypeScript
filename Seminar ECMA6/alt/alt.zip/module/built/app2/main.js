console.log("App wird gestartet!");
import { AppModule } from './app.module';
let myApp = new AppModule();
