export let lager = {
    bestand: 100,
    ausbuchen(stueck) {
        console.log("Aus dem Lager ausgebucht: ", stueck, "T-Shirts");
        this.bestand -= stueck;
    }
};
