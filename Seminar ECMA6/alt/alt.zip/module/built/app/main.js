import { shop } from './shop.module';
console.log('main geladen!');
let myShop = new shop();
