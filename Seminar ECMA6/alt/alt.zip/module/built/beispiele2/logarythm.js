function ln2() {
}
function ln10() { }
export { ln2, ln10 };
