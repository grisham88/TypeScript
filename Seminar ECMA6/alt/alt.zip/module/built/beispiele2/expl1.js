// Das ist ein Modul
console.log("Modul expl1 geladen!");
export let meinWert = 42;
export function test() {
    console.log("Ein Modultest...");
}
let val1 = 1;
let val2 = 2;
let val3 = 3;
export { val1, val2, val3 as wert3 };
