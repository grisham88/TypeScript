console.log("Hier ist Beispiele 2 !");
import { test, val2 as wert2, wert3 } from './expl1';
let val2 = "Was ganz anderes"; // Konflikt durch Aliasing gelöst!
test();
console.log("wert2:", wert2);
console.log("wert3:", wert3);
import * as math from './math';
console.log(math);
